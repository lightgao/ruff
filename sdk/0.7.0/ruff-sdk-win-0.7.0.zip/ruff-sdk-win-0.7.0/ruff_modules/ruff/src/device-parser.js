'use strict';
function InputOptions(options) {
    this._options = options || {};
}

InputOptions.prototype.getRequired = function (key) {
    if (!this._options.hasOwnProperty(key)) {
        throw new Error('Required property [' + key + '] is missing');
    }

    return this._options[key];
};

InputOptions.prototype.getOptional = function (key, defaultValue) {
    if (!this._options.hasOwnProperty(key)) {
        return defaultValue;
    }

    return this._options[key];
};

InputOptions.prototype.setValue = function (key, value) {
    this._options[key] = value;
};

function copyObjPropery(target, srcObj) {
    for (var prop in srcObj) {
        if (srcObj.hasOwnProperty(prop)) {
            target[prop] = srcObj[prop];
        }
    }
}

var DEFAULT_BIND_KEY = 'bind';

function isBind(info) {
    return (DEFAULT_BIND_KEY in info);
}

function bindDevice(id, value, ruffBox) {
    var bindValue  = value[DEFAULT_BIND_KEY];
    var bindInfo = bindValue.split('/');
    if (bindInfo.length < 2) {
        throw new Error('Invalid bind format [' + bindValue + '] for [' + id + ']');
    }

    var bindDeviceId = bindInfo[0];
    var bindDeviceOutputKey = bindInfo[1];
    var bindObj = ruffBox.getDevice(bindDeviceId);
    return bindObj.__getDevice__(bindDeviceOutputKey, new InputOptions(value.args));
}

function deviceOptions(info, ruffBox) {
    var inputs = {};

    for(var key in info.inputs) {
        var value = info.inputs[key];
        if (isBind(value)) {
            inputs[key] = bindDevice(info.id, value, ruffBox);
        } else {
            copyObjPropery(inputs, value.args);
        }
    }

    copyObjPropery(inputs, info.args);

    return new InputOptions(inputs);
}

function driverClass(driver) {
    return require(driver);
}

function checkRequired(field, message) {
    if (!field) {
        throw new Error(message);
    }

    return field;
}

function DeviceNode(devInfo, ruffBox) {
    this.id    = devInfo.id;
    this.alias = devInfo.alias;
    this.inputs = devInfo.inputs || [];
    this.args = devInfo.args;
    this.driverId = checkRequired(devInfo.driver, '[' + this.id + '] driver is missing');
    this.ruffBox = ruffBox;
    this.dev = null;
    this.outputs = devInfo.outputs;
}

var newDevice = function(DriverFunc, driverInjects) {
    return new DriverFunc(driverInjects);
};

DeviceNode.prototype.getDevice = function() {
    if (this.dev) {
        return this.dev;
    }

    var info = {
        id: this.id,
        inputs: this.inputs,
        args: this.args
    };

    this.dev = newDevice(driverClass(this.driverId), deviceOptions(info, this.ruffBox));
    return this.dev;
};

var parseDevice = function(deviceInfo, ruffBox) {
    var devNode = new DeviceNode(deviceInfo, ruffBox);
    var dev = devNode.getDevice();
    ruffBox.addDevice(deviceInfo.id, dev);
    if (deviceInfo.alias) {
        ruffBox.addDevice(deviceInfo.alias, dev);
    }
};

var parseDevices = function(configuration, ruffBox) {
    configuration.devices.forEach(function(device) {
        parseDevice(device, ruffBox);
    });
};

var parse = function(ruffBox, fileName, cb)
{
    try {
        var configuration = require(fileName);
        parseDevices(configuration, ruffBox);
    } catch (error) {
        cb(error);
        return;
    }

    cb();
};

exports.parse = parse;
exports.InputOptions = InputOptions;
