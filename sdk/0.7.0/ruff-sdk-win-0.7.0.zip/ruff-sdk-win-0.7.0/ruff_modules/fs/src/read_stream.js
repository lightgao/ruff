/* jshint ignore:start */
'use strict';

var Stream = require('stream').Stream;
var Readable = Stream.Readable;
var util = require('util');
var fs = require('./index.js');
var pool;

function ReadStream(path, options) {
    if (!(this instanceof ReadStream)) {
        return new ReadStream(path, options);
    }

    if (options === undefined) {
        options = {};
    } else if (typeof options === 'string') {
        options = {
            encoding: options
        };
    } else if (options === null || typeof options !== 'object') {
        throw new TypeError('options must be a string or an object');
    }

    // a little bit bigger buffer and water marks by default
    options = Object.create(options);
    if (options.highWaterMark === undefined) {
        options.highWaterMark = 64 * 1024;
    }

    Readable.call(this, options);

    pool = new Buffer(this._readableState.highWaterMark);

    this.path = path;
    this.fd = options.fd === undefined ? null : options.fd;
    this.flags = options.flags === undefined ? 'r' : options.flags;
    this.mode = options.mode === undefined ? parseInt('0666', 8) : options.mode;

    this.start = options.start;
    this.end = options.end;
    this.autoClose = options.autoClose === undefined ? true : options.autoClose;
    this.pos = 0;

    if (this.start !== undefined) {
        if (typeof this.start !== 'number') {
            throw new TypeError('start must be a Number');
        }
        if (this.end === undefined) {
            this.end = Infinity;
        } else if (typeof this.end !== 'number') {
            throw new TypeError('end must be a Number');
        }

        if (this.start > this.end) {
            throw new Error('start must be <= end');
        }

        this.pos = this.start;
    }

    if (typeof this.fd !== 'number') {
        this.open();
    }

    this.on('end', function() {
        if (this.autoClose) {
            this.destroy();
        }
    });
}

util.inherits(ReadStream, Readable);

ReadStream.prototype.open = function() {
    var self = this;
    fs.open(this.path, this.flags, this.mode, function(er, fd) {
        if (er) {
            if (self.autoClose) {
                self.destroy();
            }
            self.emit('error', er);
            return;
        }
        self.fd = fd;
        self.emit('open', fd);
        // start the flow of data.
        self.read();
    });
};

ReadStream.prototype._read = function(n) {
    var self = this;
    var thisPool = pool;
    var toRead = Math.min(pool.length, n);

    function onread(er, bytesRead) {
        if (er) {
            if (self.autoClose) {
                self.destroy();
            }
            self.emit('error', er);
        } else {
            var b = null;
            if (bytesRead > 0) {
                b = thisPool.slice(0, bytesRead);
            }
            self.push(b);
        }
    }

    if (typeof this.fd !== 'number') {
        return this.once('open', function() {
            self._read(n);
        });
    }
    if (this.destroyed) {
        return;
    }

    if (this.pos !== undefined && this.end !== undefined) {
        toRead = Math.min(this.end - this.pos + 1, toRead);
    }
    // already read everything we were supposed to read!
    // treat as EOF.
    if (toRead <= 0) {
        return this.push(null);
    }
    fs.read(this.fd, pool, this.pos || 0, toRead, onread);

    // move the pool positions, and internal position for reading.
    if (this.pos !== undefined) {
        this.pos += toRead;
    }
};


ReadStream.prototype.destroy = function() {
    if (this.destroyed) {
        return;
    }
    this.destroyed = true;
    this.close();
};


ReadStream.prototype.close = function(cb) {
    function close(fd) {
        fs.close(fd || self.fd, function(er) {
            if (er) {
                self.emit('error', er);
            } else {
                self.emit('close');
            }
        });
        self.fd = null;
    }

    var self = this;
    if (cb) {
        this.once('close', cb);
    }
    if (this.closed || typeof this.fd !== 'number') {
        if (typeof this.fd !== 'number') {
            this.once('open', close);
            return;
        }
        return process.nextTick(this.emit.bind(this, 'close'));
    }
    this.closed = true;
    close();
};

exports.ReadStream = ReadStream;