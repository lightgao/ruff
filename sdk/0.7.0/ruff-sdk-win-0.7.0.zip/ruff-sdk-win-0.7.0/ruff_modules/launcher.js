'use strict';
// jshint ignore: start
var fs = require('fs');
var path = require('path');

function checkandKillAppInstance() {
    var pidFileName = '/var/run/ruff_app.pid';

    if (fs.existsSync(pidFileName)) {
        var pid = fs.readFileSync(pidFileName).toString();
        uv.kill(parseInt(pid), 9);
    }
    fs.writeFileSync(pidFileName, uv.getpid().toString());
}

function launch(app) {
	var ruffBox = require('ruff');
	Object.defineProperty(global, '$', {
		get: function () {
			return ruffBox;
		}
	});

	var configuration = require(uv.cwd() + '/package.json');
	if (configuration.entry === undefined) {
		configuration.entry = '/src/index.js';
	}

	var id = path.join(uv.cwd(), configuration.entry);

	global.__appEntry = id;

	require(id);
}

checkandKillAppInstance();
//trigger uv.run here to refresh timestamp for timers
uv.run();
launch(process.argv[1]);
