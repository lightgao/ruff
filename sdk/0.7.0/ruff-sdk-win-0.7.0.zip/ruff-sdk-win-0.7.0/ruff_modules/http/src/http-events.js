'use strict';

exports.RESPONSE  = 'response';
exports.FREE      = 'free';
exports.TIMEOUT   = 'timeout';
exports.CONTINUE  = 'continue';
exports.CLOSE     = 'close';
exports.ABORTED   = '_aborted';
exports.END       = 'end';
exports.CLOSE     = 'close';
exports.ERROR     = 'error';
exports.DATA      = 'data';
exports.RESPONSE  = 'response';
exports.SOCKET    = 'socket';
exports.PREFINISH = '_prefinish';
exports.DRAIN     = '_drain';
exports.CONNECT   = 'connect';
exports.FINISH    = 'finish';
exports.ABORT     = 'abort';