/*
 * Copyright (c) 2015 Nanchao Inc. All rights reserved.
 */
'use strict';

var adcType = {
    voltage: 'voltage',
    current: 'current'
};

function getFunc(type) {

    return function() {
        if (this.__type !== type) {
            throw new Error('the type is ' + this.__type + ' donot support this method');
        }
        var voltage =
            this.__minVal +
            ((this.getRawValue() * (this.__maxVal - this.__minVal)) / Math.pow(2, this.getResolution()));
        if (type === adcType.voltage) {
            return voltage;
        } else {
            return voltage / this.__resistance;
        }
    };
}

function isFunction(func) {
    return func && typeof func === 'function';
}

function check(proto) {
    if (!isFunction(proto.getRawValue)) {
        throw new Error('getRawValue function has not implemented');
    }

    if (!isFunction(proto.getResolution)) {
        throw new Error('getResolution function has not implemented');
    }

    if (proto.getCurrent) {
        throw new Error('getCurrent function should not implemented');
    }

    if (proto.getVoltage) {
        throw new Error('getVoltage function should not implemented');
    }
}

function inspect(proto) {
    check(proto);
    proto.getCurrent = getFunc(adcType.current);
    proto.getVoltage = getFunc(adcType.voltage);
}

function driver(specification) {
    var Constructor = function(options) {
        this.__minVal = options.getRequired('min');
        this.__maxVal = options.getRequired('max');
        this.__type = options.getRequired('type');
        this.__resistance = this.__type === adcType.current ? options.getRequired('resistance') : 1;
        this.__attach__.apply(this, Array.prototype.slice.call(arguments, 1));
    };

    if (specification.attach === undefined) {
        throw new Error('attach must be specified');
    }

    Constructor.prototype.__attach__ = specification.attach;

    if (specification.exports) {
        Object.keys(specification.exports).forEach(function(key) {
            Constructor.prototype[key] = specification.exports[key];
        });
    }

    inspect(Constructor.prototype);

    Constructor.prototype.constructor = Constructor;
    return Constructor;
}

exports.driver = driver;