/*
 * Copyright (c) 2015 Nanchao Inc. All rights reserved.
 */
'use strict';

var driver = require('ruff-driver');

var REQUIRED = [
    'readByte',
    'readWord',
    'readBytes',
    'writeByte',
    'writeWord',
    'writeBytes'
];

function toI2cValue(value) {
    return value & 0xFF;
}

function toI2cWriteValue(value) {
    return value & 0xFFFF;
}

function actualI2cSpec(specification) {
    var exports = specification.exports;

    var originalReadByte = exports.readByte;
    exports.readByte = function(command) {
        if (command === null || command === undefined || command === -1) {
            command = -1;
        } else {
            command = toI2cValue(command);
        }

        return originalReadByte.call(this, command);
    };

    var originalReadWord = exports.readWord;
    exports.readWord = function(command) {
        return originalReadWord.call(this, toI2cValue(command));
    };

    var originalReadBytes = exports.readBytes;
    exports.readBytes = function(command, length) {
        if (length > 512) {
            throw new Error('I2C read bytes length exceeds max length');
        }

        if (length <= 0) {
            throw new Error('I2C read bytes length should be greater than 0');
        }

        return originalReadBytes.call(this, toI2cValue(command), length);
    };

    var originalWriteByte = exports.writeByte;
    exports.writeByte = function(command, value) {
        if (command === null || command === undefined || command === -1) {
            command = -1;
        } else {
            command = toI2cValue(command);
        }
        return originalWriteByte.call(this, command, toI2cValue(value));
    };

    var originalWriteWord = exports.writeWord;
    exports.writeWord = function(command, value) {
        return originalWriteWord.call(this, toI2cValue(command), toI2cWriteValue(value));
    };

    var originalWriteBytes = exports.writeBytes;
    exports.writeBytes = function(command, values) {
        if (!Array.isArray(values)) {
            throw new Error('I2C write values are expected to be array');
        }

        var targets = values.map(function(value) {
            return toI2cValue(value);
        });

        return originalWriteBytes.call(this, toI2cValue(command), targets);
    };

    return specification;
}

var i2c = {
    driver: function(specification) {
        REQUIRED.forEach(function(item) {
            if (typeof specification.exports[item] !== 'function') {
                throw new Error(item + ' is missing for I2C');
            }
        });

        var spec = actualI2cSpec(specification);
        return driver(spec);
    }
};

module.exports = i2c;
