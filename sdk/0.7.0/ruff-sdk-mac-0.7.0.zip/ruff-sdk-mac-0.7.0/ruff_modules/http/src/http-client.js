'use strict';
/* jshint ignore:start */

var util            = require('util');
var httpUtil        = require('./http-util.js');
var net             = require('net');
var url             = require('url');
var EventEmitter    = require('events');
var HTTPParser      = require('./http-parser.js').HTTPParser;
var assert          = require('assert').ok;
var common          = require('./http-common.js');
var httpSocketSetup = common.httpSocketSetup;
var parsers         = common.parsers;
var freeParser      = common.freeParser;
var debug           = common.debug;
var OutgoingMessage = require('./http-outgoing.js').OutgoingMessage;
var Buffer          = require('buffer').Buffer;
var httpEvent       = require('./http-events.js');
var innerWrap       = require('./http-client-inners.js').clientInnerWrap;

function normalizeCtorArgs(options, self) {
    if (typeof options === 'string') {
        options = url.parse(options);
        if (!options.hostname) {
            throw new Error('Unable to determine the domain name');
        }
    } else {
        options = httpUtil._extend({}, options);
    }

    if (options.path && / /.test(options.path)) {
        // The actual regex is more like /[^A-Za-z0-9\-._~!$&'()*+,;=/:@]/
        // with an additional rule for ignoring percentage-escaped characters
        // but that's a) hard to capture in a regular expression that performs
        // well, and b) possibly too restrictive for real-world usage. That's
        // why it only scans for spaces because those are guaranteed to create
        // an invalid request.
        throw new TypeError('Request path contains unescaped characters.');
    }

    var defaultPort = options.defaultPort;

    var port = options.port = options.port || defaultPort || 80;
    var host = options.host = options.hostname || options.host || 'localhost';

    var method = self.method = (options.method || 'GET').toUpperCase();
    if (!common._checkIsHttpToken(method)) {
        throw new TypeError('Method must be a valid HTTP token');
    }
    return {options: options, defaultPort: defaultPort, port: port, host: host, method: method};
}

function ClientRequest(options, cb) {
    var self = this;
    OutgoingMessage.call(self);

    // don't change original option's properties, so use return object's property to compute.
    var normalizedArgs = normalizeCtorArgs(options, self);
    options            = normalizedArgs.options;
    var defaultPort    = normalizedArgs.defaultPort;
    var port           = normalizedArgs.port;
    var host           = normalizedArgs.host;
    var method         = normalizedArgs.method;

    self.path = options.path || '/';
    if (cb) {
        self.once(httpEvent.RESPONSE, cb);
    }

    if (!Array.isArray(options.headers)) {
        if (options.headers) {
            var keys = Object.keys(options.headers);
            for (var i = 0, l = keys.length; i < l; i++) {
                var key = keys[i];
                self.setHeader(key, options.headers[key]);
            }
        }
        if (host && !this.getHeader('host') && options.setHost === undefined) {
            var hostHeader = host;
            if (port && +port !== defaultPort) {
                hostHeader += ':' + port;
            }
            this.setHeader('Host', hostHeader);
        }
    }

    if (options.auth && !this.getHeader('Authorization')) {
        //basic auth
        this.setHeader('Authorization', 'Basic ' +
            new Buffer(options.auth).toString('base64'));
    }

    self.useChunkedEncodingByDefault = !(method === 'GET' ||
    method === 'HEAD' ||
    method === 'DELETE' ||
    method === 'OPTIONS' ||
    method === 'CONNECT');

    if (Array.isArray(options.headers)) {
        self._storeHeader(self.method + ' ' + self.path + ' HTTP/1.1\r\n',
            options.headers);
    } else if (self.getHeader('expect')) {
        self._storeHeader(self.method + ' ' + self.path + ' HTTP/1.1\r\n',
            self._renderHeaders());
    }

    // default to Connection:close.
    self._last           = true;
    self.shouldKeepAlive = false;

    var conn = options.createConnection ? options.createConnection(options) : net.createConnection(options);
    self.onSocket(conn);

    self._deferToConnect(null, null, function () {
        self._flush();
        self = null;
    });
}

util.inherits(ClientRequest, OutgoingMessage);

function createHangUpError() {
    var error  = new Error('socket hang up');
    error.code = 'ECONNRESET';
    return error;
}

function socketCloseListener() {
    var socket = this;
    var req    = socket._httpMessage;
    //debug('HTTP socket close');

    // Pull through final chunk, if anything is buffered.
    // the ondata function will handle it properly, and this
    // is a no-op if no final chunk remains.
    socket.read();

    // NOTE: It's important to get parser here, because it could be freed by
    // the `socketOnData`.
    var parser = socket.parser;
    req.emit(httpEvent.CLOSE);
    if (req.res && req.res.readable) {
        // Socket closed before we emitted 'end' below.
        req.res.emit(httpEvent.ABORTED);
        var res = req.res;
        res.on(httpEvent.END, function () {
            res.emit(httpEvent.CLOSE);
        });
        res.push(null);
    } else if (!req.res && !req.socket._hadError) {
        // This socket error fired before we started to
        // receive a response. The error needs to
        // fire on the request.
        req.emit(httpEvent.ERROR, createHangUpError());
        req.socket._hadError = true;
    }

    // Too bad.  That output wasn't getting written.
    // This is pretty terrible that it doesn't raise an error.
    // Fixed better in v0.10
    if (req.output) {
        req.output.length = 0;
    }
    if (req.outputEncodings) {
        req.outputEncodings.length = 0;
    }

    if (parser) {
        parser.finish();
        freeParser(parser, req, socket);
    }
}

function socketOnEnd() {
    var socket = this;
    var req    = this._httpMessage;
    var parser = this.parser;

    if (!req.res && !req.socket._hadError) {
        // If we don't have a response then we know that the socket
        // ended prematurely and we need to emit an error on the request.
        req.emit(httpEvent.ERROR, createHangUpError());
        req.socket._hadError = true;
    }
    if (parser) {
        parser.finish();
        freeParser(parser, req, socket);
    }
    socket.destroy();
}

function socketOnData(d) {
    var socket = this;
    var req    = this._httpMessage;
    var parser = this.parser;

    assert(parser && parser.socket === socket);

    var ret = parser.execute(d);

    if (ret instanceof Error) {
        debug('parse error');
        freeParser(parser, req, socket);
        socket.destroy();
        req.emit(httpEvent.ERROR, ret);
        req.socket._hadError = true;
    } else if (parser.incoming && parser.incoming.upgrade) {
        // Upgrade or CONNECT
        var bytesParsed = ret;
        var res         = parser.incoming;
        req.res         = res;

        socket.removeListener(httpEvent.DATA, socketOnData);
        socket.removeListener(httpEvent.END, socketOnEnd);
        parser.finish();

        var bodyHead = d.slice(bytesParsed, d.length);

        var eventName = req.method === 'CONNECT' ? 'connect' : 'upgrade';
        if (req.listenerCount(eventName) > 0) {
            req.upgradeOrConnect = true;

            // detach the socket
            socket.removeListener(httpEvent.CLOSE, socketCloseListener);
            socket.removeListener(httpEvent.ERROR, socketErrorListener);

            // TODO(isaacs): Need a way to reset a stream to fresh state
            // IE, not flowing, and not explicitly paused.
            socket._readableState.flowing = null;

            req.emit(eventName, res, socket, bodyHead);
            req.emit(httpEvent.CLOSE);
        } else {
            // Got Upgrade header or CONNECT method, but have no handler.
            socket.destroy();
        }
        freeParser(parser, req, socket);
    } else if (parser.incoming && parser.incoming.complete &&
            // When the status code is 100 (Continue), the server will
            // send a final response after this client sends a request
            // body. So, we must not free the parser.
        parser.incoming.statusCode !== 100) {
        socket.removeListener(httpEvent.DATA, socketOnData);
        socket.removeListener(httpEvent.END, socketOnEnd);
        freeParser(parser, req, socket);
    }
}

function socketErrorListener(err) {
    var socket = this;
    var req    = socket._httpMessage;
    debug('SOCKET ERROR:', err.message, err.stack);

    if (req) {
        req.emit(httpEvent.ERROR, err);
        // For Safety. Some additional errors might fire later on
        // and we need to make sure we don't double-fire the error event.
        req.socket._hadError = true;
    }

    // Handle any pending data
    socket.read();

    var parser = socket.parser;
    if (parser) {
        parser.finish();
        freeParser(parser, req, socket);
    }

    // Ensure that no further data will come out of the socket
    socket.removeListener(httpEvent.DATA, socketOnData);
    socket.removeListener(httpEvent.END, socketOnEnd);
    socket.destroy();
}

function emitFreeNT(socket) {
    socket.emit(httpEvent.FREE);
}

// client
function responseOnEnd() {
    var res    = this;
    var req    = res.req;
    var socket = req.socket;

    if (!req.shouldKeepAlive) {
        if (socket.writable) {
            debug('AGENT socket.destroySoon()');
            socket.destroySoon();
        }
        assert(!socket.writable);
    } else {
        debug('AGENT socket keep-alive');
        if (req.timeoutCb) {
            socket.setTimeout(0, req.timeoutCb);
            req.timeoutCb = null;
        }
        socket.removeListener(httpEvent.CLOSE, socketCloseListener);
        socket.removeListener(httpEvent.ERROR, socketErrorListener);
        // Mark this socket as available, AFTER user-added end
        // handlers have a chance to run.
        process.nextTick(emitFreeNT, socket);
    }
}

// client
function parserOnIncomingClient(res, shouldKeepAlive) {

    var socket = this.socket;
    var req    = socket._httpMessage;

    // propagate "domain" setting...
    if (req.domain && !res.domain) {
        res.domain = req.domain;
    }

    if (req.res) {
        // We already have a response object, this means the server sent a double response.
        socket.destroy();
        return;
    }
    req.res = res;

    //// Responses to CONNECT request is handled as Upgrade.
    //if (req.method === 'CONNECT') {
    //    res.upgrade = true;
    //    return true; // skip body
    //}

    // Responses to HEAD requests are crazy.
    // HEAD responses aren't allowed to have an entity-body
    // but *can* have a content-length which actually corresponds
    // to the content-length of the entity-body had the request
    // been a GET.
    var isHeadResponse = req.method === 'HEAD';

    if (res.statusCode === 100) {
        // restart the parser, as this is a continue message.
        delete req.res; // Clear res so that we don't hit double-responses.
        req.emit(httpEvent.CONTINUE);
        return true;
    }

    if (req.shouldKeepAlive && !shouldKeepAlive && !req.upgradeOrConnect) {
        // Server MUST respond with Connection:keep-alive for us to enable it.
        // If we've been upgraded (via WebSockets) we also shouldn't try to
        // keep the connection open.
        req.shouldKeepAlive = false;
    }

    //DTRACE_HTTP_CLIENT_RESPONSE(socket, req);
    //LTTNG_HTTP_CLIENT_RESPONSE(socket, req);
    //COUNTER_HTTP_CLIENT_RESPONSE();
    req.res     = res;
    res.req     = req;

    // add our listener first, so that we guarantee socket cleanup
    res.on(httpEvent.END, responseOnEnd);
    var handled = req.emit(httpEvent.RESPONSE, res);

    // If the user did not listen for the 'response' event, then they
    // can't possibly read the data, so we ._dump() it into the void
    // so that the socket doesn't hang there in a paused state.
    if (!handled) {
        res._dump();
    }

    return isHeadResponse;
}

function tickOnSocket(req, socket) {

    var parser      = parsers.alloc();
    req.socket      = socket;
    req.connection  = socket;
    parser.reinitialize(HTTPParser.RESPONSE);
    parser.socket   = socket;
    parser.incoming = null;
    req.parser      = parser;

    socket.parser       = parser;
    socket._httpMessage = req;

    // Setup "drain" propagation.
    httpSocketSetup(socket);

    // Propagate headers limit from request object to parser
    if (typeof req.maxHeadersCount === 'number') {
        parser.maxHeaderPairs = req.maxHeadersCount << 1;
    } else {
        // Set default value because parser may be reused from FreeList
        parser.maxHeaderPairs = 2000;
    }

    parser.onIncoming = parserOnIncomingClient;
    socket.on(httpEvent.ERROR, socketErrorListener);
    socket.on(httpEvent.DATA, socketOnData);
    socket.on(httpEvent.END, socketOnEnd);
    socket.on(httpEvent.CLOSE, socketCloseListener);
    req.emit(httpEvent.SOCKET, socket);
}

ClientRequest.prototype.onSocket = function (socket) {
    process.nextTick(onSocketNT, this, socket);
};

function onSocketNT(req, socket) {
    if (req.aborted) {
        // If we were aborted while waiting for a socket, skip the whole thing.
        socket.emit(httpEvent.FREE);
        socket.destroy();
    } else {
        tickOnSocket(req, socket);
    }
}

ClientRequest.prototype.aborted = undefined;

function emitAbortNT(self) {
    self.emit(httpEvent.ABORT);
}

ClientRequest.prototype.abort = function () {
    if (this.aborted === undefined) {
        process.nextTick(emitAbortNT, this);
    }
    // Mark as aborting so we can avoid sending queued request data
    // This is used as a truthy flag elsewhere. The use of Date.now is for
    // debugging purposes only.
    this.aborted = Date.now();

    // If we're aborting, we don't care about any more response data.
    if (this.res) {
        this.res._dump();
    } else {
        this.once(httpEvent.RESPONSE, function (res) {
            res._dump();
        });
    }

    // In the event that we don't have a socket, we will pop out of
    // the request queue through handling in onSocket.
    if (this.socket) {
        // in-progress
        this.socket.destroy();
    }
};

innerWrap(ClientRequest.prototype);

exports.ClientRequest = ClientRequest;
