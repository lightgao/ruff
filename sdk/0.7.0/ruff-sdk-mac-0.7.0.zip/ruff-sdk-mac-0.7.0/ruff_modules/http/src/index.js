'use strict';
/* jshint ignore:start */

var ClientRequest = require('./http-client.js').ClientRequest;
var Server = require('./http-server.js').Server;

exports.request = function(options, cb) {
    return new ClientRequest(options, cb);
};

exports.get = function(options, cb) {
    var req = exports.request(options, cb);
    req.end();
    return req;
};

exports.createServer = function(requestListener) {
    return new Server(requestListener);
};

exports.ClientRequest = ClientRequest;
exports.IncomingMessage = require('./http-incoming.js').IncomingMessage;
exports.METHODS = require('./http-parser.js').HTTPParser.methods.sort();
exports.STATUS_CODES = require('./http-statuscodes.js').STATUS_CODES;