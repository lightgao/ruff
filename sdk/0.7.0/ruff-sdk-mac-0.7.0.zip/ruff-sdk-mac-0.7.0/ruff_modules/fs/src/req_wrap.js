'use strict';

var FSReqWrap = function(callback) {
    this.oncomplete = callback;
};

FSReqWrap.prototype.context = function(context) {
    this.context = context;
    return this;
};

module.exports = FSReqWrap;