'use strict';

/* jshint ignore:start */
var fsStat;
exports.FSInitialize = function(stat) {
    fsStat = stat;
};

exports.access = function() {
    uv.fs_access.apply(null, arguments);
};

function getFsStat(stat) {
    if (stat && stat.mode) {
        return new fsStat(stat.mode,
            stat.uid, stat.gid, stat.size,
            stat.atime.sec, stat.mtime.sec, stat.ctime.sec, stat.type);
    }
}

function wrapDecideCall(uvCb, args, completeCb) {
    var lastArg = args[args.length - 1];
    if (lastArg && lastArg.oncomplete && typeof lastArg.oncomplete === 'function') {
        args[args.length - 1] = completeCb || function() {
            lastArg.oncomplete.apply(lastArg, arguments);
        };
    }

    return uvCb.apply(null, args);
}

function callbackConverterStats(req) {
    return function(stats, err) {
        if (req && typeof req.oncomplete === 'function') {
            return req.oncomplete.apply(req, [err, getFsStat(stats)]);
        }
    };
}

exports.stat = function(path, req) {
    return getFsStat(wrapDecideCall(uv.fs_stat, arguments,
        callbackConverterStats(req)));
};

exports.lstat = function(path, req) {
    return getFsStat(wrapDecideCall(uv.fs_lstat, arguments,
        callbackConverterStats(req)));
};

exports.fstat = function(fd, req) {
    return getFsStat(wrapDecideCall(uv.fs_fstat, arguments,
        callbackConverterStats(req)));
};

exports.open = function(path, flag, mode, req) {
    var cbObject = req;
    return wrapDecideCall(uv.fs_open, arguments, function(fd, err) {
        cbObject.oncomplete.apply(cbObject, [err, fd]);
    });
};

exports.read = function(fd, buffer, offset, length, req) {
    if (!req || typeof req.oncomplete !== 'function') {
        var data = uv.fs_read(fd, length, offset);
        buffer.write(data.toString(), offset, length);
        return data.length;
    }
    uv.fs_read(fd, length, offset, function(data, err) {
        if (!err) {
            buffer.write(data.toString(), 0, length);
        }
        req.oncomplete.apply(req, [err, data ? data.length : 0]);
    });
};

exports.close = function(fd, req) {
    var cbObject = req;
    return wrapDecideCall(uv.fs_close, arguments, function(isSuccess) {
        cbObject.oncomplete.apply(cbObject, isSuccess ? null : new Error('close err'));
    });
};

exports.write = function(fd, buffer, offset, req) {
    var cbObject = req;
    return wrapDecideCall(uv.fs_write, arguments, function(length, err) {
        cbObject.oncomplete.apply(cbObject, [err, length, buffer]);
    });
};

function shiftError(req) {
    return function() {
        if (req && typeof req.oncomplete === 'function') {
            return req.oncomplete.apply(req, [arguments[1], arguments[0]]);
        }
    };
}

exports.unlink = function(path, req) {
    return wrapDecideCall(uv.fs_unlink, arguments, shiftError(req));
}

exports.rename = function(oldPath, newPath, req) {
    return wrapDecideCall(uv.fs_rename, arguments, shiftError(req));
};

exports.ftruncate = function(fd, len, req) {
    return wrapDecideCall(uv.fs_ftruncate, arguments, shiftError(req));
};

exports.mkdir = function(path, mode, req) {
    return wrapDecideCall(uv.fs_mkdir, arguments, shiftError(req));
};

exports.rmdir = function(path, req) {
    return wrapDecideCall(uv.fs_rmdir, arguments, shiftError(req));
};

exports.readlink = function(path, req) {
    return wrapDecideCall(uv.fs_readlink, arguments, shiftError(req));
};

exports.symlink = function(srcPath, dstPath, type, req) {
    return wrapDecideCall(uv.fs_symlink, arguments, shiftError(req));
};

exports.link = function(srcPath, dstPath, type, req) {
    return wrapDecideCall(uv.fs_link, arguments, shiftError(req));
};

exports.fchmod = function(fd, mode, req) {
    return wrapDecideCall(uv.fs_fchmod, arguments, shiftError(req));
};

exports.chmod = function(path, mode, req) {
    return wrapDecideCall(uv.fs_chmod, arguments, shiftError(req));
};

exports.fchown = function(fd, uid, gid, req) {
    return wrapDecideCall(uv.fs_fchown, arguments, shiftError(req));
};

exports.chown = function(fd, uid, gid, req) {
    return wrapDecideCall(uv.fs_chown, arguments, shiftError(req));
};

exports.utimes = function(path, atime, mtime, req) {
    return wrapDecideCall(uv.fs_utime, arguments, shiftError(req));
};

exports.futimes = function(fd, atime, mtime, req) {
    return wrapDecideCall(uv.fs_futime, arguments, shiftError(req));
};

exports.fdatasync = function(fd, req) {
    return wrapDecideCall(uv.fs_fdatasync, arguments, shiftError(req));
};

exports.fsync = function(fd, req) {
    return wrapDecideCall(uv.fs_fsync, arguments, shiftError(req));
};