'use strict';

/* jshint ignore:start */
// TODO the watch has not completed with C , so pause achieve it 
var EventEmitter = require('events');
var util = require('util');
var fsUtil = require('./fs_util.js');

function FSWatcher() {
    EventEmitter.call(this);
}
util.inherits(FSWatcher, EventEmitter);

FSWatcher.prototype.start = function(filename) {
    this.wd = uv.fs_watch(filename, function() {
        console.log(arguments);
    });
    console.log(this.wd);
};

FSWatcher.prototype.close = function() {
    if (this.wd) {
        uv.fs_stop_watch(this.wd);
    }
};

function StatWatcher() {
    EventEmitter.call(this);

    var self = this;
    this._handle = new binding.StatWatcher();

    // uv_fs_poll is a little more powerful than ev_stat but we curb it for
    // the sake of backwards compatibility
    var oldStatus = -1;

    this._handle.onchange = function(current, previous, newStatus) {
        if (oldStatus === -1 &&
            newStatus === -1 &&
            current.nlink === previous.nlink) return;

        oldStatus = newStatus;
        self.emit('change', current, previous);
    };

    this._handle.onstop = function() {
        self.emit('stop');
    };
}
util.inherits(StatWatcher, EventEmitter);


StatWatcher.prototype.start = function(filename, persistent, interval) {
    nullCheck(filename);
    this._handle.start(pathModule._makeLong(filename), persistent, interval);
};


StatWatcher.prototype.stop = function() {
    this._handle.stop();
};

exports.FSWatcher = FSWatcher;
exports.StatWatcher = StatWatcher;