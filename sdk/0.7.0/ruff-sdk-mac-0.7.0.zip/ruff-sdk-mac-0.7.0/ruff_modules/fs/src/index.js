/* jshint ignore:start */
'use strict';

var SlowBuffer = require('buffer').Buffer;
var pathModule = require('path');
var binding = require('./binding.js');
var Buffer = require('buffer').Buffer;
var fsUtil = require('./fs_util.js');
var ReadFileContext = require('./read_file_context.js');
var FSReqWrap = require('./req_wrap.js');
var ReadStream = require('./read_stream.js').ReadStream;
var WriteStream = require('./write_stream.js').WriteStream;
var SyncWriteStream = require('./write_stream.js').SyncWriteStream;
// var FSWatcher = require('./watcher.js').FSWatcher;

var isWindows = false; // TODO
var kMaxLength = require('buffer').kMaxLength;

var TypeStats = {
    S_IFDIR: 'directory',
    S_IFREG: 'file',
    S_IFBLK: 'block',
    S_IFCHR: 'char',
    S_IFLNK: 'link',
    S_IFIFO: 'fifo',
    S_IFSOCK: 'socket'
};

var ModeType = {
    RW: parseInt('0666', 8),
    All: parseInt('0777', 8)
};

var fs = exports;

// Static method to set the stats properties on a Stats object.
fs.Stats = function(mode, uid, gid, size, atime, mtime, ctime, type) {
    this.mode = mode;
    this.uid = uid;
    this.gid = gid;
    this.size = size;
    this.atime = new Date(atime * 1000);
    this.mtime = new Date(mtime * 1000);
    this.ctime = new Date(ctime * 1000);
    this.type = type;
};

// Create a binding to the function which creates a Stats object.
binding.FSInitialize(fs.Stats);

fs.Stats.prototype._checkModeProperty = function(property) {
    return this.type === property;
};

fs.Stats.prototype.isDirectory = function() {
    return this._checkModeProperty(TypeStats.S_IFDIR);
};

fs.Stats.prototype.isFile = function() {
    return this._checkModeProperty(TypeStats.S_IFREG);
};

fs.Stats.prototype.isBlockDevice = function() {
    return this._checkModeProperty(TypeStats.S_IFBLK);
};

fs.Stats.prototype.isCharacterDevice = function() {
    return this._checkModeProperty(TypeStats.S_IFCHR);
};

fs.Stats.prototype.isSymbolicLink = function() {
    return this._checkModeProperty(TypeStats.S_IFLNK);
};

fs.Stats.prototype.isFIFO = function() {
    return this._checkModeProperty(TypeStats.S_IFIFO);
};

fs.Stats.prototype.isSocket = function() {
    return this._checkModeProperty(TypeStats.S_IFSOCK);
};

fs.access = function(path, mode, callback) {
    if (typeof mode === 'function') {
        callback = mode;
        mode = 'r';
    } else if (typeof callback !== 'function') {
        throw new TypeError('callback must be a function');
    }

    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }

    binding.access(pathModule._makeLong(path), mode, fsUtil.makeCallback(callback));
};

fs.accessSync = function(path, mode) {
    fsUtil.nullCheck(path);
    binding.access(pathModule._makeLong(path), mode || 'r');
};

fs.exists = function(path, callback) {
    function cb(err) {
        if (callback) {
            callback(err ? false : true);
        }
    }
    if (!fsUtil.nullCheck(path, cb)) {
        return;
    }
    binding.stat(pathModule._makeLong(path), new FSReqWrap(cb));
};

fs.existsSync = function(path) {
    try {
        fsUtil.nullCheck(path);
        binding.stat(pathModule._makeLong(path));
        return true;
    } catch (e) {
        return false;
    }
};

fs.fstat = function(fd, callback) {
    binding.fstat(fd, new FSReqWrap(fsUtil.makeCallback(callback)));
};

fs.lstat = function(path, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }
    binding.lstat(pathModule._makeLong(path), new FSReqWrap(callback));
};

fs.stat = function(path, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }
    binding.stat(pathModule._makeLong(path), new FSReqWrap(callback));
};

fs.fstatSync = function(fd) {
    return binding.fstat(fd);
};

fs.lstatSync = function(path) {
    fsUtil.nullCheck(path);
    return binding.lstat(pathModule._makeLong(path));
};

fs.statSync = function(path) {
    fsUtil.nullCheck(path);
    return binding.stat(pathModule._makeLong(path));
};

function readFileAfterStat(err, st) {
    var context = this.context; // jshint ignore:line

    if (err) {
        return context.close(err);
    }

    var size = context.size = st.isFile() ? st.size : 0;

    if (size === 0) {
        context.buffers = [];
        context.read();
        return;
    }

    if (size > kMaxLength) {
        err = new RangeError('File size is greater than possible Buffer: 0x' + kMaxLength.toString(16) + 'bytes');
        return context.close(err);
    }

    context.buffer = new SlowBuffer(size);
    context.read();
}

function readFileAfterOpen(err, fd) {
    var context = this.context; // jshint ignore:line

    if (err) {
        context.callback(err);
        return;
    }

    context.fd = fd;
    binding.fstat(fd, new FSReqWrap(readFileAfterStat).context(context));
}

fs.readFile = function(path, options) {
    var callback = fsUtil.maybeCallback(arguments[arguments.length - 1]);
    options = fsUtil.converterReadOptions(options);

    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }
    binding.open(pathModule._makeLong(path), options.flag, ModeType.RW,
        new FSReqWrap(readFileAfterOpen).context(
            new ReadFileContext(callback, options.encoding, binding)));
};

fs.openSync = function(path, flag, mode) {
    return binding.open(pathModule._makeLong(path), flag, mode || ModeType.RW);
};

fs.closeSync = function(fd) {
    return binding.close(fd);
};

function getFileSize(fd) {
    return fsUtil.withCloseWhenError(fs, fd, function() {
        var st = fs.fstatSync(fd);
        return st.isFile() ? st.size : 0;
    });
}

function getBuffer(size, fd) {
    if (size > 0) {
        return fsUtil.withCloseWhenError(fs, fd, function() {
            return new Buffer(size);
        });
    }
}

fs.readSync = function(fd, buffer, offset, length) {
    return binding.read(fd, buffer, offset, length);
};

fs.readFileSync = function(path, options) {
    options = fsUtil.converterReadOptions(options);
    var fd = fs.openSync(path, options.flag || 'r', ModeType.RW);
    var size = getFileSize(fd);
    var buffer = getBuffer(size, fd); // single buffer with file data
    var buffers = []; // list for when size is unknown
    var pos = 0;
    fsUtil.withCloseWhenError(fs, fd, function() {
        var done = false;
        var bytesRead;
        while (!done) {
            if (size !== 0) {
                bytesRead = fs.readSync(fd, buffer, pos, size - pos);
            } else {
                // the kernel lies about many files.
                // Go ahead and try to read some bytes.
                buffer = new Buffer(8192);
                bytesRead = fs.readSync(fd, buffer, 0, 8192);
                if (bytesRead) {
                    buffers.push(buffer.slice(0, bytesRead));
                }
            }
            pos += bytesRead;
            done = (bytesRead === 0) || (size !== 0 && pos >= size);
        }
    });

    fs.closeSync(fd);

    if (size === 0) {
        // data was collected into the buffers list.
        buffer = Buffer.concat(buffers, pos);
    } else if (pos < size) {
        buffer = buffer.slice(0, pos);
    }

    if (options.encoding) {
        buffer = buffer.toString(options.encoding);
    }
    return buffer;
};

fs.open = function(path, flags, mode) {
    var callback = fsUtil.makeCallback(arguments[arguments.length - 1]);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }

    binding.open(pathModule._makeLong(path), flags, mode, new FSReqWrap(callback));
};

fs.read = function(fd, buffer, offset, length, callback) {
    function wrapper(err, bytesRead) {
        // Retain a reference to buffer so that it can't be GC'ed too soon.
        if (callback) {
            callback(err, bytesRead || 0, buffer);
        }
    }

    binding.read(fd, buffer, offset, length, new FSReqWrap(wrapper));
};

fs.close = function(fd, callback) {
    binding.close(fd, new FSReqWrap(fsUtil.makeCallback(callback)));
};

// usage:
//  fs.write(fd, buffer, [offset,] callback);
// OR
//  fs.write(fd, string, [offset,] callback);
fs.write = function(fd, buffer, offset, callback) {
    // callback(err, written || 0, buffer);
    if (typeof buffer !== 'string' && !(buffer instanceof Buffer)) {
        throw new TypeError('invalid data');
    }

    if (buffer instanceof Buffer) {
        buffer = buffer.toString();
    }

    if (typeof offset === 'function') {
        callback = offset;
        offset = 0;
    }

    return binding.write(fd, buffer, offset, new FSReqWrap(fsUtil.maybeCallback(callback)));
};

fs.writeSync = function(fd, buffer, offset) {
    // callback(err, written || 0, buffer);
    if (typeof buffer !== 'string' && !(buffer instanceof Buffer)) {
        throw new TypeError('invalid data');
    }

    if (buffer instanceof Buffer) {
        buffer = buffer.toString();
    }

    return binding.write(fd, buffer, offset || 0);
};

function writeAll(fd, buffer, offset) {
    var callback = fsUtil.maybeCallback(arguments[arguments.length - 1]);
    fs.write(fd, buffer, offset, function(writeErr, written) {
        if (writeErr) {
            fs.close(fd, function() {
                if (callback) {
                    callback(writeErr);
                }
            });
        } else {
            if (written === buffer.length) {
                fs.close(fd, callback);
            } else {
                offset += written;
                writeAll(fd, buffer.slice(written), offset, callback);
            }
        }
    });
}

fs.writeFile = function(path, data, options) {
    var callback = fsUtil.maybeCallback(arguments[arguments.length - 1]);

    options = fsUtil.converterWriteOptions(options, ModeType.RW);

    fs.open(path, options.flag || 'w', options.mode,
        fsUtil.callErrorWhenError(callback, function(openErr, fd) {
            var buffer = (data instanceof Buffer) ? data : new Buffer('' + data,
                options.encoding || 'utf8');
            writeAll(fd, buffer, 0, callback);
        }));
};

fs.writeFileSync = function(path, data, options) {
    options = fsUtil.converterWriteOptions(options, ModeType.RW);

    if (!(data instanceof Buffer)) {
        data = new Buffer('' + data, options.encoding || 'utf8');
    }

    var fd = fs.openSync(path, options.flag || 'w', options.mode);

    fsUtil.withCloseWhenError(fs, fd, function() {
        var offset = 0;
        while (data.length - offset > 0) {
            var written = fs.writeSync(fd, data.slice(offset), offset);
            offset += written;
        }
        return offset;
    });
};

fs.appendFile = function(path, data, options) {
    var callback = fsUtil.maybeCallback(arguments[arguments.length - 1]);
    options = fsUtil.converterAppendOptions(options, ModeType.RW);

    fs.open(path, options.flag || 'a', options.mode,
        fsUtil.callErrorWhenError(callback, function(openErr, fd) {
            fs.fstat(fd, fsUtil.callErrorWhenError(callback, function(statErr, stat) {
                var buffer = (data instanceof Buffer) ? data : new Buffer('' + data,
                    options.encoding || 'utf8');
                writeAll(fd, buffer, stat.size, callback);
            }));
        }));
};

fs.appendFileSync = function(path, data, options) {
    options = fsUtil.converterAppendOptions(options, ModeType.RW);

    if (!(data instanceof Buffer)) {
        data = new Buffer('' + data, options.encoding || 'utf8');
    }

    var fd = fs.openSync(path, options.flag || 'w', options.mode);
    fsUtil.withCloseWhenError(fs, fd, function() {
        var offset = 0;
        var pos = getFileSize(fd);
        while (data.length - offset > 0) {
            var written = fs.writeSync(fd, data.slice(offset), pos + offset);
            offset += written;
        }
        return offset;
    });
};

fs.rename = function(oldPath, newPath, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(oldPath, callback)) {
        return;
    }
    if (!fsUtil.nullCheck(newPath, callback)) {
        return;
    }
    binding.rename(pathModule._makeLong(oldPath),
        pathModule._makeLong(newPath),
        new FSReqWrap(callback));
};

fs.renameSync = function(oldPath, newPath) {
    fsUtil.nullCheck(oldPath);
    fsUtil.nullCheck(newPath);
    return binding.rename(pathModule._makeLong(oldPath),
        pathModule._makeLong(newPath));
};

fs.unlink = function(path, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }
    binding.unlink(pathModule._makeLong(path), new FSReqWrap(callback));
};

fs.unlinkSync = function(path) {
    fsUtil.nullCheck(path);
    return binding.unlink(pathModule._makeLong(path));
};

fs.ftruncate = function(fd, len, callback) {
    if (typeof len === 'function') {
        callback = len;
        len = 0;
    } else if (len === undefined) {
        len = 0;
    }
    binding.ftruncate(fd, len, new FSReqWrap(fsUtil.makeCallback(callback)));
};

fs.ftruncateSync = function(fd, len) {
    if (len === undefined) {
        len = 0;
    }
    return binding.ftruncate(fd, len);
};

fs.truncate = function(path, len, callback) {
    if (typeof len === 'function') {
        callback = len;
        len = 0;
    } else if (len === undefined) {
        len = 0;
    }

    callback = fsUtil.maybeCallback(callback);
    fs.open(path, 'r+', fsUtil.callErrorWhenError(function(er, fd) {
        binding.ftruncate(fd, len, new FSReqWrap(function() {
            fs.close(fd, function(er2) {
                callback(er || er2);
            });
        }));
    }));
};

fs.truncateSync = function(path, len) {
    if (len === undefined) {
        len = 0;
    }
    // allow error to be thrown, but still close fd.
    var fd = fs.openSync(path, 'r+', ModeType.RW);
    return fsUtil.withCloseWhenError(fs, fd, function() {
        return fs.ftruncateSync(fd, len);
    });
};

fs.mkdir = function(path, mode, callback) {
    if (typeof mode === 'function') {
        callback = mode;
        mode = ModeType.All;
    }
    binding.mkdir(pathModule._makeLong(path), mode || ModeType.All, new FSReqWrap(fsUtil.makeCallback(callback)));
};

fs.mkdirSync = function(path, mode) {
    fsUtil.nullCheck(path);
    return binding.mkdir(pathModule._makeLong(path), mode || ModeType.All);
};

fs.rmdir = function(path, callback) {
    callback = fsUtil.maybeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }
    binding.rmdir(pathModule._makeLong(path), new FSReqWrap(callback));
};

fs.rmdirSync = function(path) {
    fsUtil.nullCheck(path);
    return binding.rmdir(pathModule._makeLong(path));
};

fs.readlink = function(path, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }

    binding.readlink(pathModule._makeLong(path), new FSReqWrap(callback));
};

fs.readlinkSync = function(path) {
    fsUtil.nullCheck(path);
    return binding.readlink(pathModule._makeLong(path));
};

fs.symlink = function(destination, path, type) {
    type = (typeof type === 'string' ? type : null);
    var callback = fsUtil.makeCallback(arguments[arguments.length - 1]);

    if (!fsUtil.nullCheck(destination, callback)) {
        return;
    }
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }

    binding.symlink(fsUtil.preprocessSymlinkDestination(destination, type, path),
        pathModule._makeLong(path),
        type,
        new FSReqWrap(callback));
};

fs.symlinkSync = function(destination, path, type) {
    type = (typeof type === 'string' ? type : null);

    fsUtil.nullCheck(destination);
    fsUtil.nullCheck(path);

    return binding.symlink(fsUtil.preprocessSymlinkDestination(isWindows, destination, type, path),
        pathModule._makeLong(path),
        type);
};

fs.link = function(srcpath, dstpath, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(srcpath, callback)) {
        return;
    }
    if (!fsUtil.nullCheck(dstpath, callback)) {
        return;
    }

    binding.link(pathModule._makeLong(srcpath),
        pathModule._makeLong(dstpath),
        new FSReqWrap(callback));
};

fs.linkSync = function(srcpath, dstpath) {
    fsUtil.nullCheck(srcpath);
    fsUtil.nullCheck(dstpath);
    return binding.link(pathModule._makeLong(srcpath),
        pathModule._makeLong(dstpath));
};

fs.fchmod = function(fd, mode, callback) {
    binding.fchmod(fd, mode, new FSReqWrap(fsUtil.makeCallback(callback)));
};

fs.fchmodSync = function(fd, mode) {
    return binding.fchmod(fd, mode);
};

fs.chmod = function(path, mode, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }
    binding.chmod(pathModule._makeLong(path),
        mode,
        new FSReqWrap(callback));
};

fs.chmodSync = function(path, mode) {
    fsUtil.nullCheck(path);
    return binding.chmod(pathModule._makeLong(path), mode);
};

fs.fchown = function(fd, uid, gid, callback) {
    binding.fchown(fd, uid, gid, new FSReqWrap(fsUtil.makeCallback(callback)));
};

fs.fchownSync = function(fd, uid, gid) {
    return binding.fchown(fd, uid, gid);
};

fs.chown = function(path, uid, gid, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }

    binding.chown(pathModule._makeLong(path), uid, gid, new FSReqWrap(callback));
};

fs.chownSync = function(path, uid, gid) {
    fsUtil.nullCheck(path);
    return binding.chown(pathModule._makeLong(path), uid, gid);
};

fs.utimes = function(path, atime, mtime, callback) {
    callback = fsUtil.makeCallback(callback);
    if (!fsUtil.nullCheck(path, callback)) {
        return;
    }
    binding.utimes(pathModule._makeLong(path),
        fsUtil.toUnixTimestamp(atime),
        fsUtil.toUnixTimestamp(mtime),
        new FSReqWrap(callback));
};

fs.utimesSync = function(path, atime, mtime) {
    fsUtil.nullCheck(path);
    binding.utimes(pathModule._makeLong(path),
        fsUtil.toUnixTimestamp(atime),
        fsUtil.toUnixTimestamp(mtime));
};

fs.futimes = function(fd, atime, mtime, callback) {
    binding.futimes(fd,
        fsUtil.toUnixTimestamp(atime),
        fsUtil.toUnixTimestamp(mtime),
        new FSReqWrap(callback));
};

fs.futimesSync = function(fd, atime, mtime) {
    binding.futimes(fd,
        fsUtil.toUnixTimestamp(atime),
        fsUtil.toUnixTimestamp(mtime));
};

fs.fdatasync = function(fd, callback) {
    binding.fdatasync(fd, new FSReqWrap(fsUtil.makeCallback(callback)));
};

fs.fdatasyncSync = function(fd) {
    return binding.fdatasync(fd);
};

fs.fsync = function(fd, callback) {
    binding.fsync(fd, new FSReqWrap(fsUtil.makeCallback(callback)));
};

fs.fsyncSync = function(fd) {
    return binding.fsync(fd);
};

// Regexp that finds the next partion of a (partial) path
// result is [base_with_slash, base], e.g. ['somedir/', 'somedir']
if (isWindows) {
    var nextPartRe = /(.*?)(?:[\/\\]+|$)/g;
} else {
    var nextPartRe = /(.*?)(?:[\/]+|$)/g;
}

// Regex to find the device root, including trailing slash. E.g. 'c:\\'.
if (isWindows) {
    var splitRootRe = /^(?:[a-zA-Z]:|[\\\/]{2}[^\\\/]+[\\\/][^\\\/]+)?[\\\/]*/;
} else {
    var splitRootRe = /^[\/]*/;
}

fs.realpathSync = function(p, cache) {
    // make p is absolute
    p = pathModule.resolve(p);
    if (cache && Object.prototype.hasOwnProperty.call(cache, p)) {
        return cache[p];
    }

    var original = p;
    var knownHard = {};

    // current character position in p
    var pos;
    // the partial path so far, including a trailing slash if any
    var current;

    function checkRootExits() {
        // On windows, check that the root exists. On unix there is no need.
        if (isWindows && !knownHard[current]) {
            fs.lstatSync(current);
            knownHard[current] = true;
        }
    }

    function start() {
        // Skip over roots
        var m = splitRootRe.exec(p);
        pos = m[0].length;
        current = m[0];

        checkRootExits();
    }

    start();

    // walk down the path, swapping out linked pathparts for their real  values
    // NB: p.length changes.
    while (pos < p.length) {
        // find the next part
        nextPartRe.lastIndex = pos;
        var result = nextPartRe.exec(p);
        // the partial path scanned in the previous round, with slash
        var previous = current;
        var base = previous + result[1];
        current += result[0];
        pos = nextPartRe.lastIndex;

        // continue if not a symlink
        if (knownHard[base] || (cache && cache[base] === base)) {
            continue;
        }

        var resolvedLink;
        if (cache && Object.prototype.hasOwnProperty.call(cache, base)) {
            // some known symbolic link.  no need to stat again.
            resolvedLink = cache[base];
        } else {
            var stat = fs.lstatSync(base);
            if (!stat.isSymbolicLink()) {
                knownHard[base] = true;
                if (cache) {
                    cache[base] = base;
                }
                continue;
            }

            // read the link if it wasn't read before
            var linkTarget = fs.readlinkSync(base);
            resolvedLink = pathModule.resolve(previous, linkTarget);
            // track this, if given a cache.
            if (cache) {
                cache[base] = resolvedLink;
            }
        }

        // resolve the link, then start over
        p = pathModule.resolve(resolvedLink, p.slice(pos));

        start();
    }

    if (cache) {
        cache[original] = p;
    }

    return p;
};

fs.realpath = function(p, cache, cb) {
    if (typeof cb !== 'function') {
        cb = fsUtil.maybeCallback(cache);
        cache = null;
    }

    // make p is absolute
    p = pathModule.resolve(p);

    if (cache && Object.prototype.hasOwnProperty.call(cache, p)) {
        return process.nextTick(cb.bind(null, null, cache[p]));
    }

    var original = p;
    var knownHard = {};

    // current character position in p
    var pos;
    // the partial path so far, including a trailing slash if any
    var current;
    // the partial path without a trailing slash (except when pointing at a root)
    var base;
    // the partial path scanned in the previous round, with slash
    var previous;

    function initP() {
        // Skip over roots
        var m = splitRootRe.exec(p);
        pos = m[0].length;
        current = m[0];
        base = m[0];
        previous = '';
    }

    function start() {
        initP();
        // On windows, check that the root exists. On unix there is no need.
        if (isWindows && !knownHard[base]) {
            fs.lstat(base, function(err) {
                if (err) {
                    return cb(err);
                }
                knownHard[base] = true;
                LOOP();
            });
        } else {
            process.nextTick(LOOP);
        }
    }

    function gotResolvedLink(resolvedLink) {
        // resolve the link, then start over
        p = pathModule.resolve(resolvedLink, p.slice(pos));
        start();
    }

    function gotTarget(err, target, base) {
        if (err) {
            return cb(err);
        }
        var resolvedLink = pathModule.resolve(previous, target);
        if (cache) {
            cache[base] = resolvedLink;
        }
        gotResolvedLink(resolvedLink);
    }

    function gotStat(err, stat) {
        if (err) {
            return cb(err);
        }
        // if not a symlink, skip to the next path part
        if (!stat.isSymbolicLink()) {
            knownHard[base] = true;
            if (cache) {
                cache[base] = base;
            }
            return process.nextTick(LOOP);
        }
        // stat & read the link if not read before
        fs.stat(base, function(err) {
            if (err) {
                return cb(err);
            }
            fs.readlink(base, function(err, target) {
                gotTarget(err, target);
            });
        });
    }

    // walk down the path, swapping out linked pathparts for their real
    // values
    function LOOP() {
        // stop if scanned past end of path
        if (pos >= p.length) {
            if (cache) {
                cache[original] = p;
            }
            return cb(null, p);
        }

        // find the next part
        nextPartRe.lastIndex = pos;
        var result = nextPartRe.exec(p);
        previous = current;
        current += result[0];
        base = previous + result[1];
        pos = nextPartRe.lastIndex;

        // continue if not a symlink
        if (knownHard[base] || (cache && cache[base] === base)) {
            return process.nextTick(LOOP);
        }

        if (cache && Object.prototype.hasOwnProperty.call(cache, base)) {
            // known symbolic link.  no need to stat again.
            return gotResolvedLink(cache[base]);
        }
        return fs.lstat(base, gotStat);
    }

    start();
};

fs.createReadStream = function(path, options) {
    return new ReadStream(path, options);
};

fs.ReadStream = ReadStream;

fs.createWriteStream = function(path, options) {
    return new WriteStream(path, options);
};

fs.WriteStream = WriteStream;

// Export
fs.SyncWriteStream = SyncWriteStream;