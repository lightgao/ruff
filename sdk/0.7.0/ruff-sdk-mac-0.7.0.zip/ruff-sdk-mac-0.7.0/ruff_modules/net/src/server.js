'use strict';
/* jshint ignore:start */
var EventEmitter = require('events');
var util = require('util');
var netUtil = require('./net-util.js');
var onceListener = netUtil.onceListener;
var Socket = require('./socket.js').Socket;
var netEvents = require('./net-events.js');
var normalizeArgs = require('./net-normalizeArgs.js');
var cleanupWrap = require('./server-cleanup.js').serverCleanupWrap;
var propertyWrap = require('./server-property.js').serverPropertyWrap;

function Server(options, connectionListener) {
    // handle situation that invoke Server without new keyword.
    if (!(this instanceof Server)) {
        return new Server(options, connectionListener);
    }

    EventEmitter.call(this);

    netUtil.onListener(this, netEvents.CONNECTION, connectionListener);

    this._connections = 0;
    this._uvHandle = null;
    options = options || {};
    this.allowHalfOpen = !!options.allowHalfOpen;
    this.pauseOnConnect = !!options.pauseOnConnect;
}
util.inherits(Server, EventEmitter);

function onClientConnected(server, clientHandle) {
    // reject when overload.
    if (server.maxConnections && server._connections >= server.maxConnections) {
        uv.close(clientHandle);
        return;
    }

    var socket = new Socket({
        handle: clientHandle,
        allowHalfOpen: server.allowHalfOpen,
        pauseOnCreate: server.pauseOnConnect
    });
    socket.readable = socket.writable = true;
    server._connections++;
    socket.server = server;

    socket.readStart();
    server.emit(netEvents.CONNECTION, socket);
}

function listen(server, address, port, backlog) {
    server._uvHandle = uv.new_tcp();
    try {
        uv.tcp_bind(server._uvHandle, address, port);
        uv.listen(server._uvHandle, backlog, function() {
            var clientHandle = uv.new_tcp();
            uv.accept(server._uvHandle, clientHandle);
            onClientConnected(server, clientHandle);
        });

        process.nextTick(netUtil.emitEvent, server, netEvents.LISTENING);
    } catch (err) {
        var ex = netUtil.exceptionWithHostPort(err, 'listen', address, port);
        uv.close(server._uvHandle);
        server._uvHandle = null;
        process.nextTick(netUtil.emitErrorEvent, server, ex);
    }
}

Server.prototype.listen = function() {
    onceListener(this, netEvents.LISTENING, arguments[arguments.length - 1]);

    if (this._uvHandle) {
        return;
    }

    var args = normalizeArgs.normalizeListenArgs(arguments);
    listen(this, args[0], args[1], args[2]);
};

cleanupWrap(Server.prototype);
propertyWrap(Server.prototype);
exports.Server = Server;