'use strict';

var parser = require('./device-parser.js');
var parse = parser.parse;

/**
 * Container to hold all devices object on board
 * @class
 */
var RuffBox = function() {
    this._devices = {};
};

/**
 * Add Device object to device tree
 *
 * @param {Device} device
 */
RuffBox.prototype.addDevice = function(id, device) {
    this._devices[id] = device;
    return device;
};

/**
 * Get Device object from device tree
 *
 * @param {String} id
 * @returns {Device} or undefined if not found
 */

RuffBox.prototype.getDevice = function(id) {
    if (arguments.length < 1) {
        throw new Error('Device id is expected');
    }

    if (!(id in this._devices)) {
        throw new Error('No device found for ' + id);
    }

    return this._devices[id];
};

RuffBox.prototype.parseFromFile = function(fileName, cb) {
    parse(this, fileName, cb);
};

var ruffBox = new RuffBox();

var loadRuffBox = ruffBox.parseFromFile.bind(ruffBox);

function RuffBoxAtExit(ruffBox) {
    this.atExit = [];
    this.signal = uv.signal_init(); // jshint ignore:line
    this.tiggerd = false;
    this.signalNum = 2; //SIGINT
    this.ruffBox = ruffBox;
}

RuffBoxAtExit.prototype.push = function(cb) {
    this.atExit.push(cb);
    if (!this.tiggerd) {
        uv.signal_start(this.signal, this.signalNum, this.trigger.bind(this)); // jshint ignore:line
    }
};

RuffBoxAtExit.prototype.trigger = function() {
    var that = this.ruffBox;
    var deviceName;
    var device;
    var detach;

    this.atExit.forEach(function(cb) {
        cb();
    });

    for(deviceName in that._devices) {
        device = that.getDevice(deviceName);
        detach = device.__detach__;
        if (detach) {
            detach.apply(device);
        }
    }
};

var atExit = new RuffBoxAtExit(ruffBox);

/** @module ruff */

/**
 * ruff box $
 * @function $
 * @param {string} id - device id
 * @returns {Device} - device object
 *
 */
var $ = ruffBox.getDevice.bind(ruffBox);

/**
 * entry of device box ready
 * @function ready
 * @param {callback} cb - user callback
 * @param {string} fileName - ruff box file
 * @default 'ruff.json'
 * @access public
 *
 */
$.ready = function(cb, fileName) {
    var realName;
    if (arguments.length === 1) {
        realName = uv.cwd() + '/' + 'ruff_box.json'; // jshint ignore:line
    } else {
        realName = fileName;
    }
    loadRuffBox(realName, cb);
};


/**
 * entry of end function for APP to register cleanup callback
 * @function end
 * @param {callback} cb - user callback
 *
 * @access public
 */
$.end = function(cb) {
    atExit.push(cb);
};

module.exports = $;
