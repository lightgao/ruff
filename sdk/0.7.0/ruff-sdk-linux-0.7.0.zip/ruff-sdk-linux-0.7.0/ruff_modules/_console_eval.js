'use strict';

var net = require('net');
var EventEmitter = require('events');
var util = require('util');

var hop = Object.prototype.hasOwnProperty;

exports.eval = function () { };

function Parser() {
	EventEmitter.call(this);
	this.pending = new Buffer(0);
}

util.inherits(Parser, EventEmitter);

Parser.prototype.append = function (buffer) {
	this.pending = Buffer.concat([this.pending, buffer]);
	this.parse();
};

Parser.prototype.parse = function () {
	var buffer = this.pending;

	while (buffer.length) {
		var length = buffer.readUInt32BE(0);
		var end = length + 4;

		if (buffer.length < end) {
			break;
		}

		var json = buffer.toString('utf-8', 4, end);

		try {
			this.emit('data', JSON.parse(json));
		} catch (error) {
			this.emit('error', error);
		}

		buffer = buffer.slice(end);
	}

	this.pending = buffer;
};

function encode(data) {
    var json = JSON.stringify(data);

    var dataBuffer = new Buffer(json);
    var length = dataBuffer.length;

    var lengthBuffer = new Buffer(4);
    lengthBuffer.writeUInt32BE(length);

    return Buffer.concat([lengthBuffer, dataBuffer]);
}

var actions = {
	eval: function (data) {
		return exports.eval.call(undefined, data.expression);
	}
};

var server = net.createServer(function (socket) {
	console.log('Console client connected.');

	var parser = new Parser();

	parser.on('data', function (data) {
		if (!data) {
			return;
		}

		var type = data.type;
		var hasError;
		var value;

		if (hop.call(actions, type)) {
			try {
				value = util.inspect(actions[type](data), {
					colors: true
				});
				hasError = false;
			} catch (error) {
				value = error && error.stack || error;
				hasError = true;
			}
		}

		socket.write(encode({
			error: hasError,
			value: value
		}));
	});

	socket.on('data', function (data) {
		parser.append(new Buffer(data));
	});

	socket.on('error', function () { });
});

server.listen(7884, function () {
	console.log('Console server bound.');
});
