/*jshint bitwise: false*/
'use strict';

// a duplex stream is just a stream that is both readable and writable.
// Since JS doesn't have multiple prototypal inheritance, this class
// prototypally inherits from Readable, and then parasitically from
// Writable.
var util     = require('util');
var Readable = require('_stream_readable.js');
var Writable = require('_stream_writable.js');

function onEndNT(self) {
	self.end();
}

// the no-half-open enforcer
function onend() {
	// if we allow half-open state, or if the writable side ended,
	// then we're ok.
	/* jshint validthis: true */
	if (this.allowHalfOpen || this._writableState.ended) {
		return;
	}

	// no more data can be written.
	// But allow more writes to happen in this tick.
	process.nextTick(onEndNT, this);
}

function isExplicitlySetFalse(options, property) {
	return options && options[property] === false;
}
function Duplex(options) {
	if (!(this instanceof Duplex)) {
		return new Duplex(options);
	}

	Readable.call(this, options);
	Writable.call(this, options);

	if (isExplicitlySetFalse(options, 'readable')) {
		this.readable = false;
	}

	if (isExplicitlySetFalse(options, 'writable')) {
		this.writable = false;
	}

	this.allowHalfOpen = !isExplicitlySetFalse(options, 'allowHalfOpen');

	this.once('end', onend);// jshint ignore:line
}

util.inherits(Duplex, Readable);

// copy methods from Writable.
var keys = Object.keys(Writable.prototype);
for (var v = 0; v < keys.length; v++) {
	var method = keys[v];
	if (!Duplex.prototype[method]) {
		Duplex.prototype[method] = Writable.prototype[method];
	}
}

module.exports = Duplex;