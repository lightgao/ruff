'use strict';
var SlowBuffer = require('buffer').Buffer;
var FSReqWrap = require('./req_wrap.js');
var kReadFileBufferLength = 8 * 1024;

function readFileAfterRead(err, bytesRead) {
    var context = this.context; // jshint ignore:line

    if (err) {
        return context.close(err);
    }

    if (bytesRead === 0) {
        return context.close();
    }

    context.pos += bytesRead;

    if (context.size === context.pos) {
        return context.close();
    }

    if (context.size === 0) {
        // unknown size, just read until we don't get bytes.
        context.buffers.push(context.buffer.slice(0, bytesRead));
    }

    context.read();
}

function readFileAfterClose(err) {
    var context = this.context; // jshint ignore:line
    var buffer = null;
    var callback = context.callback;

    if (context.err) {
        return callback(context.err);
    }

    if (context.size === 0) {
        buffer = Buffer.concat(context.buffers, context.pos);
    } else if (context.pos < context.size) {
        buffer = context.buffer.slice(0, context.pos);
    } else {
        buffer = context.buffer;
    }

    if (context.encoding) {
        buffer = buffer.toString(context.encoding);
    }

    callback(err, buffer);
}

function ReadFileContext(callback, encoding, binding) {
    this.fd = undefined;
    this.size = undefined;
    this.callback = callback;
    this.buffers = null;
    this.buffer = null;
    this.pos = 0;
    this.encoding = encoding;
    this.err = null;
    this.binding = binding;
}

ReadFileContext.prototype.read = function() {
    var buffer;
    var offset;
    var length;

    if (this.size === 0) {
        buffer = this.buffer = new SlowBuffer(kReadFileBufferLength);
        offset = 0;
        length = kReadFileBufferLength;
    } else {
        buffer = this.buffer;
        offset = this.pos;
        length = this.size - this.pos;
    }

    this.binding.read(this.fd, buffer, offset, length, new FSReqWrap(readFileAfterRead).context(this));
};

ReadFileContext.prototype.close = function(err) {
    this.err = err;
    this.binding.close(this.fd, new FSReqWrap(readFileAfterClose).context(this));
};

module.exports = ReadFileContext;