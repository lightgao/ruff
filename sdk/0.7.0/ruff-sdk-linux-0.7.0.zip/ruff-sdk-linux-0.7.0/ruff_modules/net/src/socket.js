'use strict';
/* jshint ignore:start */
var EventEmitter        = require('events');
var util                = require('util');
var netUtil             = require('./net-util.js');
var readWriteWrap       = require('./socket-data.js').readWriteWrap;
var cleanupWrap         = require('./socket-cleanup.js').socketCleanupWrap;
var readWriteEndingWrap = require('./socket-data-ending.js').readWriteEndingWrap;
var socketPropertyWrap  = require('./socket-property.js').socketPropertyWrap;
var socketConnectWrap   = require('./socket-connect.js').socketConnectWrap;
var netEvents           = require('./net-events.js');

function initSocket() {
    this._uvHandle    = null;
    this.destroyed    = false;
    this.state        = {};
    this.errorEmitted = this.state.ending = this.state.ended = this.state.endEmitted = this.state.finished = false;
    this._connecting = false; // indicate whether in connecting status now.
}

function initProperties(options) {
    initSocket.call(this);

    options            = options || {};
    this.allowHalfOpen = options && options.allowHalfOpen || false; // default to *not* allowing half open sockets
    if (options.handle) {
        this._uvHandle = options.handle;
    } else {
        this.readable = this.writable = false; // these will be set once there is a connection
    }
}

function afterHandleCreated(options) {
    // if we have a handle, then start the flow of data into the buffer, otherwise this will happen when we connect.
    if (this._uvHandle && options.readable) {
        if (options.pauseOnCreate) {
            uv.read_stop(this._uvHandle); // stop the handle from reading and pause the stream
        } else {
            this.read();
        }
    }
}

function Socket(options) {
    if (!(this instanceof Socket)) {
        return new Socket(options);
    }

    EventEmitter.call(this);

    this.on(netEvents.SOCKETEND, this._onSocketEnd);

    initProperties.call(this, options);
    afterHandleCreated.call(this, options);
}

util.inherits(Socket, EventEmitter);

function initUvHandle() {
    if (!this._uvHandle) {
        this._uvHandle = uv.new_tcp.call(this);
        this.destroyed = false;
    }
}

function cleanupStatus() {
    initSocket.call(this);
}

Socket.prototype.connect = function (options, cb) {
    if (this.destroyed) {
        cleanupStatus.call(this);
    }
    initUvHandle.call(this);
    netUtil.onceListener(this, netEvents.CONNECT, cb);

    this._connecting = true;
    this.writable    = true;

    this._lookupAndConnect(options);
};

readWriteWrap(Socket.prototype);
cleanupWrap(Socket.prototype);
readWriteEndingWrap(Socket.prototype);
socketPropertyWrap(Socket.prototype);
socketConnectWrap(Socket.prototype);

exports.Socket = Socket;
