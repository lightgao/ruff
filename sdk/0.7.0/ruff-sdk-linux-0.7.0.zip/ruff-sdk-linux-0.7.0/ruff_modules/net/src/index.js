'use strict';
/* jshint ignore:start */
var normalizeArgs = require('./net-normalizeArgs.js');
var Server = require('./server.js').Server;
var Socket = require('./socket.js').Socket;
var netUtil = require('./net-util.js');

exports.Server = Server;

exports.createServer = function(options, connectionListener) {
    var args = normalizeArgs.normalizeCreateServerArgs(options, connectionListener);
    return new Server(args[0], args[1]);
};

exports.connect = exports.createConnection = function() {
    var args = normalizeArgs.normalizeConnectArgs(arguments);

    var client = new Socket(args[0]);
    Socket.prototype.connect.apply(client, args);
    return client;
};
exports.Socket = Socket;
exports.isIP = netUtil.isIP;
exports.isIPv4 = function(input) {
    return 4 === exports.isIP(input);
};
exports.isIPv6 = function(input) {
    return 6 === exports.isIP(input);
};
