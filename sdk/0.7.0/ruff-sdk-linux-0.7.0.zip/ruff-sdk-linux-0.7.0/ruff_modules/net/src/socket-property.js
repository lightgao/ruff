'use strict';
/* jshint ignore:start */
var netEvents = require('./net-events.js');

function socketPropertyWrap(proto) {

    proto.setNoDelay = function (enable) {
        if (!this._uvHandle) {
            this.once(netEvents.CONNECT, enable ? this.setNoDelay : this.setNoDelay.bind(this, enable));
            return this;
        }
        uv.tcp_nodelay(this._uvHandle, enable === undefined ? true : !!enable);
        return this;
    };

    proto.setKeepAlive = function (setting, msecs) {
        if (!this._uvHandle) {
            this.once(netEvents.CONNECT, this.setKeepAlive.bind(this, setting, msecs));
            return this;
        }
        uv.tcp_keepalive(this._uvHandle, setting, ~~(msecs / 1000));
        return this;
    };

    proto.address = function () {
        return this._getSockName();
    };

    proto._getSockName = function () {
        if (this._uvHandle !== null) {
            return uv.tcp_getsockname(this._uvHandle);
        } else {
            return {};
        }
    };

    Object.defineProperty(proto, 'localAddress', {
        get: function () {
            return this._getSockName().ip;
        }
    });

    Object.defineProperty(proto, 'localPort', {
        get: function () {
            return this._getSockName().port;
        }
    });

    proto._getPeerName = function () {
        if (this._uvHandle !== null) {
            return uv.tcp_getpeername(this._uvHandle);
        } else {
            return {};
        }
    };

    Object.defineProperty(proto, 'remoteAddress', {
        get: function () {
            return this._getPeerName().ip;
        }
    });

    Object.defineProperty(proto, 'remoteFamily', {
        get: function () {
            return this._getPeerName().family;
        }
    });

    Object.defineProperty(proto, 'remotePort', {
        get: function () {
            return this._getPeerName().port;
        }
    });
}

exports.socketPropertyWrap = socketPropertyWrap;
