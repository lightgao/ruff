/* jshint ignore:start */
'use strict';

var util = require('util');
var pSlice = Array.prototype.slice;

function Expectation(methodName, _arguments, answers, handler) {
    this.methodName = methodName;
    this.expectedArguments = _arguments;
    this.answers = answers;
    this.handler = handler;
    this.current = 0;
}

Expectation.prototype._currentAnswer = function() {
    if (this.current < this.answers.length) {
        return this.answers[this.current++];
    }

    return this.answers[this.answers.length - 1];
};

Expectation.prototype.currentAnswer = function() {
    return this.handler(this._currentAnswer());
};

function startStub(mockObject) {
    mockObject.onStub = true;
}

function endStub(mockObject) {
    mockObject.onStub = false;
}

function _Any() {}

// 7. The equivalence assertion tests a deep equality relation.
// assert.deepEqual(actual, expected, message_opt);
function isArguments(object) {
    return Object.prototype.toString.call(object) === '[object Arguments]';
}

function objectToString(o) {
    return Object.prototype.toString.call(o);
}

function isDate(d) {
    return objectToString(d) === '[object Date]';
}

function isRegExp(re) {
    return objectToString(re) === '[object RegExp]';
}

function isPrimitive(arg) {
    return arg === null ||
        typeof arg !== 'object' && typeof arg !== 'function';
}

function objEquiv(a, b, strict) {
    if (a === null || a === undefined || b === null || b === undefined) {
        return false;
    }
    // if one is a primitive, the other must be same
    if (isPrimitive(a) || isPrimitive(b)) {
        return a === b;
    }
    if (strict && Object.getPrototypeOf(a) !== Object.getPrototypeOf(b)) {
        return false;
    }
    var aIsArgs = isArguments(a),
        bIsArgs = isArguments(b);
    if ((aIsArgs && !bIsArgs) || (!aIsArgs && bIsArgs)) {
        return false;
    }
    if (aIsArgs) {
        a = pSlice.call(a);
        b = pSlice.call(b);
        return _deepEqual(a, b, strict);
    }
    var ka = Object.keys(a),
        kb = Object.keys(b),
        key, i;
    // having the same number of owned properties (keys incorporates
    // hasOwnProperty)
    if (ka.length !== kb.length) {
        return false;
    }
    //the same set of keys (although not necessarily the same order),
    ka.sort();
    kb.sort();
    //~~~cheap key test
    for (i = ka.length - 1; i >= 0; i--) {
        if (ka[i] !== kb[i]) {
            return false;
        }
    }
    //equivalent values for every corresponding key, and
    //~~~possibly expensive deep test
    for (i = ka.length - 1; i >= 0; i--) {
        key = ka[i];
        if (!_deepEqual(a[key], b[key], strict)) {
            return false;
        }
    }
    return true;
}

function _deepEqual(actual, expected, strict) { // jshint ignore:line
    // 7.1. All identical values are equivalent, as determined by ===.
    if (actual === expected) {
        return true;
    } else if (actual instanceof Buffer && expected instanceof Buffer) {
        return actual.compare(expected) === 0; // jshint ignore:line

    // 7.2. If the expected value is a Date object, the actual value is
    // equivalent if it is also a Date object that refers to the same time.
    } else if (isDate(actual) && isDate(expected)) {
        return actual.getTime() === expected.getTime();

    // 7.3 If the expected value is a RegExp object, the actual value is
    // equivalent if it is also a RegExp object with the same source and
    // properties (`global`, `multiline`, `lastIndex`, `ignoreCase`).
    } else if (isRegExp(actual) && isRegExp(expected)) {
        return actual.source === expected.source &&
            actual.global === expected.global &&
            actual.multiline === expected.multiline &&
            actual.lastIndex === expected.lastIndex &&
            actual.ignoreCase === expected.ignoreCase;

    // 7.4. Other pairs that do not both pass typeof value == 'object',
    // equivalence is determined by ==.
    } else if ((actual === null || typeof actual !== 'object') &&
        (expected === null || typeof expected !== 'object')) {
        return strict ? actual === expected : actual == expected; // jshint ignore:line

    // 7.5 For all other Object pairs, including Array objects, equivalence is
    // determined by having the same number of owned properties (as verified
    // with Object.prototype.hasOwnProperty.call), the same set of keys
    // (although not necessarily the same order), equivalent values for every
    // corresponding key, and an identical 'prototype' property. Note: this
    // accounts for both named and indexed properties on Arrays.
    } else {
        return objEquiv(actual, expected, strict);
    }
}

function match(mockArguments, actualArguments) {
    if (mockArguments instanceof _Any) {
        return true;
    }

    if (isArguments(mockArguments) && isArguments(actualArguments)) {
        if (mockArguments.length !== actualArguments.length) {
            return false;
        }

        for (var i = 0; i < mockArguments.length; i++) {
            if (!match(mockArguments[i], actualArguments[i])) {
                return false;
            }
        }

        return true;
    } else {
        return _deepEqual(mockArguments, actualArguments, true);
    }
}

function isTargetFunction(field) {
    return typeof field === 'function' && field !== 'constructor';
}

function doTimes(expected) {
    if (expected < 0) {
        throw new Error('Expected invocation times should be greater than 0');
    }

    return {
        verify: function(data) {
            if (data.length !== expected) {
                throw new Error(util.format('Expect invoke %d times but actual %d times', expected, data.length));
            }
        }
    };
}

function toVerificationMode(mode) {
    if (mode === undefined) {
        return doTimes(1);
    }

    return mode;
}

function interceptedMethod(methodName, targetObject, defaultHandler) {
    return function() {
        if (targetObject.onStub) {
            throw new Error('unfinished when, invoke then please');
        }

        targetObject.invocations.push({
            name: methodName,
            arguments: arguments
        });

        var _arguments = arguments;
        var expectations = targetObject.expectations[methodName];
        if (expectations) {
            var results = expectations.filter(function(expectation) {
                return match(expectation.expectedArguments, _arguments);
            });

            if (results.length > 0) {
                return results[0].currentAnswer();
            }
        }

        if (typeof defaultHandler === 'undefined') {
            return undefined;
        }

        return defaultHandler(arguments);
    };
}

function mockMethod(methodName, mockObject) {
    return interceptedMethod(methodName, mockObject);
}

function spyMethod(spyObject, methodName, targetMethod) {
    return interceptedMethod(methodName, spyObject, function(_arguments) {
        return targetMethod.apply(spyObject, _arguments);
    });
}

function setExpectation(whenObject, methodName, _arguments, answers, handler) {
    if (!whenObject.expectations[methodName]) {
        whenObject.expectations[methodName] = [];
    }

    whenObject.expectations[methodName].push(new Expectation(methodName, _arguments, answers, handler));
    endStub(whenObject);
}

function whenMethod(whenObject, methodName) {
    return function() {
        var expectedArgs = arguments;
        return {
            then: function() {
                setExpectation(whenObject, methodName, expectedArgs, arguments, function(value) {
                    return value();
                });
            },

            thenReturn: function() {
                setExpectation(whenObject, methodName, expectedArgs, arguments, function(value) {
                    return value;
                });
            },

            thenThrow: function() {
                setExpectation(whenObject, methodName, expectedArgs, arguments, function(value) {
                    throw value;
                });
            }
        };
    };
}

function verificationMethod(methodName, verificationObject) {
    return function() {
        var _arguments = arguments;
        var matchResult = verificationObject.mockObject.invocations.filter(function(invocation) {
            return invocation.name === methodName && match(_arguments, invocation.arguments);
        });

        verificationObject.mode.verify(matchResult);
    };
}

function anyIntercepted(obj, methodHandler) {
    var handler = {
        get: function(target, key) {
            if (!(key in target)) {
                target[key] = methodHandler(key, obj);
            }

            return target[key];
        }
    };

    return new Proxy(obj, handler);
}

function interceptable() {
    return {
        expectations: {},
        invocations: [],
        onStub: false,
    };
}

module.exports = {
    mock: function(clazz) {
        var mockObject = interceptable();

        for (var field in clazz.prototype) {
            var clazzField = clazz.prototype[field];
            if (isTargetFunction(clazzField)) {
                mockObject[field] = mockMethod(field, mockObject);
            }
        }

        return mockObject;
    },

    spy: function(obj) {
        var spyObject = interceptable();

        for (var fm in obj) {
            if (obj[fm] === 'constructor') {
                continue;
            } else if (typeof obj[fm] === 'function') {
                spyObject[fm] = spyMethod(spyObject, fm, obj[fm]);
            } else {
                spyObject[fm] = obj[fm];
            }
        }
        return spyObject;
    },

    anyMock: function() {
        var anyMockObject = interceptable();

        return anyIntercepted(anyMockObject, function(key) {
            return mockMethod(key, anyMockObject);
        });
    },

    when: function(mockObject) {
        startStub(mockObject);

        return anyIntercepted({}, function(key) {
            return whenMethod(mockObject, key);
        });
    },

    verify: function(mockObject, verificationMode) {
        var verificationObject = {
            mockObject: mockObject,
            mode: toVerificationMode(verificationMode)
        };

        for (var prop in mockObject) {
            if (isTargetFunction(mockObject[prop])) {
                verificationObject[prop] = verificationMethod(prop, verificationObject);
            }
        }

        return anyIntercepted(verificationObject, function(key) {
            return verificationMethod(key, verificationObject);
        });
    },

    any: function() {
        return new _Any();
    },

    times: function(expected) {
        return doTimes(expected);
    },

    once: function() {
        return doTimes(1);
    },

    twice: function() {
        return doTimes(2);
    },

    never: function() {
        return doTimes(0);
    },

    atLeast: function(expected) {
        return {
            verify: function(data) {
                if (data.length < expected) {
                    throw new Error(util.format('Expect invoke at least %d times but actual %d times', expected, data.length));
                }
            }
        };
    },

    atMost: function(expected) {
        return {
            verify: function(data) {
                if (data.length > expected) {
                    throw new Error(util.format('Expect invoke at most %d times but actual %d times', expected, data.length));
                }
            }
        };
    }
};