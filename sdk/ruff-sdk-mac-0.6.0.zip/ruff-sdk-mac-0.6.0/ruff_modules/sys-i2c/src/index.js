/*
 * Copyright (c) 2015 Nanchao Inc. All rights reserved.
 */

'use strict';
var driver = require('ruff-driver');
var i2c = require('i2c');

var transaction = {
    I2C_SMBUS_QUICK:            0,
    I2C_SMBUS_BYTE:             1,
    I2C_SMBUS_BYTE_DATA:        2,
    I2C_SMBUS_WORD_DATA:        3,
    I2C_SMBUS_PROC_CALL:        4,
    I2C_SMBUS_BLOCK_DATA:       5,
    I2C_SMBUS_I2C_BLOCK_BROKEN: 6,
    I2C_SMBUS_BLOCK_PROC_CALL:  7,      /* SMBus 2.0 */
    I2C_SMBUS_I2C_BLOCK_DATA:   8
};

var I2cDevice = i2c.driver({
    attach: function(options, systemI2c) {
        this._bus      = options.getRequired('bus');
        this._address  = options.getRequired('address');
        this._i2c      = systemI2c;
        this._handle   = this._i2c.open(this._bus, this._address);
    },

    detach: function() {
        if (this._handle > 0) {
            this._i2c.close(this._handle);
            this._handle = -1;
        }
    },

    exports: {
        readByte: function (command) {
            return this._i2c.read(this._handle, command, transaction.I2C_SMBUS_BYTE_DATA);
        },

        readWord: function (command) {
            return this._i2c.read(this._handle, command, transaction.I2C_SMBUS_WORD_DATA);
        },

        readBytes: function (command, length) {
            return this._i2c.read(this._handle, command, transaction.I2C_SMBUS_I2C_BLOCK_DATA, length);
        },

        writeByte: function (command, value) {
            if (command === -1) {
                return this._i2c.write(this._handle, value, transaction.I2C_SMBUS_BYTE);
            } else {
                return this._i2c.write(this._handle, command, transaction.I2C_SMBUS_BYTE_DATA, value);
            }
        },

        writeWord: function (command, value) {
            return this._i2c.write(this._handle, command, transaction.I2C_SMBUS_WORD_DATA, value);
        },

        writeBytes: function (command, values) {
            return this._i2c.write(this._handle, command, transaction.I2C_SMBUS_I2C_BLOCK_DATA, values);
        }
    }
});

module.exports = driver({
    attach: function(options, systemI2c) {
        this._bus = options.getRequired('bus');
        this._i2c = systemI2c || global.fakeI2c || require('./i2c.so');
    },

    getDevice: function(key, options) {
        options.setValue('bus', this._bus);
        return new I2cDevice(options, this._i2c);
    }
});
