/*jshint bitwise: false*/
'use strict';

function judgeEncoding(encoding) {
    var encodings = ['hex', 'utf8', 'utf-8', 'ascii', 'binary', 'base64', 'ucs2', 'ucs-2', 'utf16le', 'utf-16le'];
    return encodings.indexOf(encoding.toLowerCase()) > -1;
}

function validateEncoding(encoding) {
    if (!encoding) {
        encoding = 'utf8';
    }
    if (!judgeEncoding(encoding)) {
        throw new TypeError('Unknown encoding: ' + encoding);
    }
}

function validateRange(start, end, msg) {
    msg = msg || '';
    start = start >> 0;
    /*jshint validthis:true */
    end = (end === undefined) ? this.length : end >> 0;

    if (start < 0 || end > this.length || start > end) {
        throw new RangeError(msg);
    }
}

Buffer.prototype._fill = Buffer.prototype.fill;
Buffer.prototype.fill = function fill(val, start, end) {
    validateRange.call(this, start, end, 'out of range index');

    this._fill(val, start, end);
    return this;
};

Buffer.prototype._toString = Buffer.prototype.toString;
Buffer.prototype.toString = function () {
    validateEncoding(arguments[0]);

    return this._toString.apply(this, arguments);
};

Buffer.prototype._write = Buffer.prototype.write;
Buffer.prototype.write = function (string, offset, length, encoding) {
    if (offset === undefined) {
        // Buffer#write(string);
        encoding = 'utf8';
        length = this.length;
        offset = 0;
    } else if (length === undefined && typeof offset === 'string') {
        // Buffer#write(string, encoding)
        encoding = offset;
        length = this.length;
        offset = 0;
    } else if (isFinite(offset)) {
        // Buffer#write(string, offset[, length][, encoding])
        offset = offset >>> 0;
        if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === undefined) {
                encoding = 'utf8';
            }
        } else {
            encoding = length;
            length = undefined;
        }
    }

    var remaining = this.length - offset;
    if (length === undefined || length > remaining) {
        length = remaining;
    }

    if (remaining < 0) {
        throw new RangeError('attempt to write outside buffer bounds');
    }

    if (string.length > 0 && (length < 0 || offset < 0)) {
        throw new RangeError('attempt to write outside buffer bounds');
    }

    validateEncoding(encoding);

    return this._write.call(this, string, offset, length, encoding);
};

Buffer.isEncoding = judgeEncoding;

exports.Buffer = Buffer;
