'use strict';

var util = require('util');

function assertPath(path) {
    if (typeof path !== 'string') {
        throw new TypeError('Path must be a string. Received ' + util.inspect(path));
    }
}

// resolves . and .. elements in a path array with directory names, there must be no slashes in the array
// (so also no leading and trailing slashes - it does not distinguish relative and absolute paths)
function normalizeArray(parts, allowAboveRoot) {
    var res = [];
    for (var i = 0; i < parts.length; i++) {
        var p = parts[i];

        // ignore empty parts or current folder char.
        if (!p || p === '.') {
            continue;
        }

        if (p === '..') {
            if (res.length && res[res.length - 1] !== '..') {
                res.pop();
            } else if (allowAboveRoot) {
                // only push  .. when not in relative path situation.
                res.push('..');
            }
        } else {
            res.push(p);
        }
    }

    return res;
}

// Returns an array with empty elements removed from either end of the input
// array or the original array if no elements need to be removed
function trimArray(arr) {
    var lastIndex = arr.length - 1;
    var start = 0;
    for (; start <= lastIndex; start++) {
        if (arr[start]) {
            break;
        }
    }

    var end = lastIndex;
    for (; end >= 0; end--) {
        if (arr[end]) {
            break;
        }
    }

    if (start === 0 && end === lastIndex) {
        return arr;
    }
    if (start > end) {
        return [];
    }
    return arr.slice(start, end + 1);
}

// Split a filename into [root, dir, basename, ext], unix version
// 'root' is just a slash, or nothing.
var splitPathRe = /^(\/?|)([\s\S]*?)((?:\.{1,2}|[^\/]+?|)(\.[^.\/]*|))(?:[\/]*)$/;
var posix = {};

function posixSplitPath(filename) {
    var out = splitPathRe.exec(filename);
    out.shift();
    return out;
}

// path.resolve([from ...], to)
// At this point the path should be resolved to a full absolute path, but handle relative paths to be safe.
posix.resolve = function() {
    var resolvedPath = '';
    var resolvedAbsolute = false;

    for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i--) {
        var path = arguments[i];

        assertPath(path);

        // Skip empty entries
        if (path === '') {
            continue;
        }

        resolvedPath = path + '/' + resolvedPath;
        resolvedAbsolute = path[0] === '/';
    }

    // Normalize the path
    resolvedPath = normalizeArray(resolvedPath.split('/'), !resolvedAbsolute).join('/');

    return ((resolvedAbsolute ? '/' : '') + resolvedPath) || '.';
};

posix.normalize = function(path) {
    assertPath(path);

    var isAbsolute = posix.isAbsolute(path);
    // if path ends with slash, we will preserve it in the result.
    var trailingSlash = path && path[path.length - 1] === '/';

    path = normalizeArray(path.split('/'), !isAbsolute).join('/');

    if (!path && !isAbsolute) {
        path = '.';
    }
    if (path && trailingSlash) {
        path += '/';
    }

    return (isAbsolute ? '/' : '') + path;
};

posix.isAbsolute = function(path) {
    assertPath(path);
    return !!path && path[0] === '/';
};

posix.join = function() {
    var path = '';
    // first, combine paths to one path string.
    for (var i = 0; i < arguments.length; i++) {
        var segment = arguments[i];
        assertPath(segment);
        if (segment) {
            path += (path ? '/' : '') + segment;
        }
    }
    return posix.normalize(path);
};


posix.relative = function(from, to) {
    assertPath(from);
    assertPath(to);

    from = posix.resolve(from).substr(1);
    to = posix.resolve(to).substr(1);

    var fromParts = trimArray(from.split('/'));
    var toParts = trimArray(to.split('/'));

    var length = Math.min(fromParts.length, toParts.length);
    var samePartsLength = length;
    for (var i = 0; i < length; i++) {
        if (fromParts[i] !== toParts[i]) {
            samePartsLength = i;
            break;
        }
    }

    var outputParts = [];
    for (var j = samePartsLength; j < fromParts.length; j++) {
        outputParts.push('..');
    }

    outputParts = outputParts.concat(toParts.slice(samePartsLength));

    return outputParts.join('/');
};


posix._makeLong = function(path) {
    return path;
};


posix.dirname = function(path) {
    var result = posixSplitPath(path);
    var root = result[0];
    var dir = result[1];

    if (!root && !dir) {
        // No dirname whatsoever
        return '.';
    }

    if (dir) {
        // It has a dirname, strip trailing slash
        dir = dir.substr(0, dir.length - 1);
    }

    return root + dir;
};


posix.basename = function(path, ext) {
    if (ext !== undefined && typeof ext !== 'string') {
        throw new TypeError('ext must be a string');
    }

    var f = posixSplitPath(path)[2];

    if (ext && f.substr(-1 * ext.length) === ext) {
        f = f.substr(0, f.length - ext.length);
    }
    return f;
};


posix.extname = function(path) {
    return posixSplitPath(path)[3];
};


posix.format = function(pathObject) {
    if (pathObject === null || typeof pathObject !== 'object') {
        throw new TypeError(
            'Parameter \'pathObject\' must be an object, not ' + typeof pathObject
        );
    }

    var root = pathObject.root || '';

    if (typeof root !== 'string') {
        throw new TypeError(
            '\'pathObject.root\' must be a string or undefined, not ' + typeof pathObject.root
        );
    }

    var dir = pathObject.dir ? pathObject.dir + posix.sep : '';
    var base = pathObject.base || '';
    return dir + base;
};


posix.parse = function(pathString) {
    assertPath(pathString);

    var allParts = posixSplitPath(pathString);
    return {
        root: allParts[0],
        dir: allParts[0] + allParts[1].slice(0, -1),
        base: allParts[2],
        ext: allParts[3],
        name: allParts[2].slice(0, allParts[2].length - allParts[3].length)
    };
};

posix.sep = '/';
posix.delimiter = ':';

module.exports = posix;