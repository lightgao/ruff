/*
 * Copyright (c) 2015 Nanchao Inc. All rights reserved.
 */

'use strict';

var Gpio = require('gpio');

var gpioInterrupt;

function GpioInterrupt(gpio) {
    var handle     = gpio.interrupt_init();  // jshint ignore:line
    var pollHandle = uv.fs_poll_init(handle); // jshint ignore:line
    var listeners  = {};
    var started    = false;

    var checkAndEmitMsg = function() {
        var events = gpio.interrupt_get_events(handle, 0); // jshint ignore:line
        events.forEach(function(key) {
            var gpio = listeners[key].gpio;
            var msg  = listeners[key].msg;
            var value = gpio.read();

            gpio.emit(msg, value);
        });
    };

    var start = function() {
        uv.fs_poll_start( // jshint ignore:line
            pollHandle,
            1, // care only read event
            function(fdStatus, fdEvent) { // jshint ignore:line
                checkAndEmitMsg();
            }
	    );
    };

    //ToDo Implement stop
    var stop = function() { // jshint ignore:line
        uv.fs_poll_stop(pollHandle); // jshint ignore:line
    };

    this.watch = function(gpioHandle, gpioObj, msg) {
        if (!started) {
            start();
            started = true;
        }
        var key = gpio.interrupt_enable(handle, gpioHandle); // jshint ignore:line
        listeners[key] = {gpio: gpioObj, msg: msg};
    };

    this.unWatch = function(gpioHandle) {
        var key = gpio.interrupt_disable(handle, gpioHandle); // jshint ignore:line
        delete listeners[key];
    };
}

function getGpioInterrupt (gpio) {
    if (gpioInterrupt === undefined) {
        gpioInterrupt = new GpioInterrupt(gpio);
    }

    return gpioInterrupt;
}

var enableInterrupt = function(gpioHandle, gpioObj, message) {
    getGpioInterrupt(gpioObj._gpio).watch(gpioHandle, gpioObj, message);
};

var disableInterrupt = function(gpioHandle, gpioObj) {
    getGpioInterrupt(gpioObj._gpio).unWatch(gpioHandle);
};

/*
 * handle : a handle on GPIO in C bindings
 * pin    : Pin number
 * error : reserved errno
 */

var SysGpio = Gpio.driver({
    attach: function(opitons, gpio) {
        this._gpio = gpio || global.fakeGpio || require('./gpio.so');
        this._handle = -1;
    },

    detach: function() {
        if (this._handle !== -1) {
            this._gpio.close(this._handle);
            this._handle = -1;
        }
    },

    getDevice: function(key, inputs) {
        var directionText = inputs.getOptional('direction', 'in');
        var edgeText  = inputs.getOptional('edge', 'none');
        var isActiveLow = inputs.getOptional('active_low', false);
        var direction = Gpio.toDirection(directionText);
        var edge      = Gpio.toEdge(edgeText);

        this._handle = this._gpio.open(this._pin);

        if (isActiveLow) {
            this.setActiveLow(1);
        } else {
            this.setActiveLow(0);
        }

        this.setDirection(direction);
        if (this.getDiection() === Gpio.IN) {
            this.setEdge(edge);
        }

        this.interruptEnabled = false;
        return this;
    },

    exports: {
        setDirection: function(direction) {
            this._gpio.setDirection(this._handle, direction);
        },

        read: function() {
            return this._gpio.read(this._handle);
        },

        write: function(value) {
            this._gpio.write(this._handle, value);
        },

        setEdge: function(edge) {
            this._gpio.setEdge(this._handle, edge);
        },

        setActiveLow: function(isActiveLow) {
            var data = 0;
            if (isActiveLow) {
                data = 1;
            }
            this._gpio.setActiveLow(this._handle, data);
        }
    },

    events: {
        'interrupt' : 'notify interrupt coming'
    }
});

SysGpio.prototype._on = SysGpio.prototype.on;
SysGpio.prototype._removeListener = SysGpio.prototype.removeListener;

SysGpio.prototype.on = function(msg, callback) {
    if (msg === SysGpio.interruptMsg) {
        this._on(SysGpio.interruptMsg, callback);

        if (!this.interruptEnabled) {
            //clear events first
            this.read();
            enableInterrupt(this._handle, this, SysGpio.interruptMsg);
            this.interruptEnabled = true;
        }
    } else {
        this._on(msg, callback);
    }
};

SysGpio.prototype.removeListener = function(msg, callback) {
    if (msg === SysGpio.interruptMsg) {
        this._removeListener(msg, callback);

        if (this.listenerCount(SysGpio.interruptMsg) === 0) {
            disableInterrupt(this._handle, this);
            this.interruptEnabled = false;
        }
    } else {
        this._removeListener(msg, callback);
    }
};

SysGpio.interruptMsg = 'interrupt';

module.exports = SysGpio;
