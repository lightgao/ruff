'use strict';
var EventEmitter  = require('events');
var mixin = require('util').mixin;

function detachFunc(detach) {
    if (detach) {
        return detach;
    }

    return function() {};
}

function getDeviceFunc(getDevice) {
    if (getDevice) {
        return getDevice;
    }

    return function() {
        return this;
    };
}

function driver(specification) {
    var Constructor = function() {
        EventEmitter.call(this);
        this.__attach__.apply(this, arguments);
    };

    mixin(Constructor, [EventEmitter]);

    if (specification.attach === undefined) {
        throw new Error('attach must be specified');
    }

    Constructor.prototype.__attach__ = specification.attach;
    Constructor.prototype.__detach__ = detachFunc(specification.detach);
    Constructor.prototype.__getDevice__ = getDeviceFunc(specification.getDevice);

    if (specification.exports) {
        Object.keys(specification.exports).forEach(function(key) {
            Constructor.prototype[key] = specification.exports[key];
        });
    }

    Constructor.prototype.constructor = Constructor;
    return Constructor;
}

module.exports = driver;
