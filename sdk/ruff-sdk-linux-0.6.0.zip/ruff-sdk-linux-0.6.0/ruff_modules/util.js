'use strict';

var debugs = {};
var debugEnviron;

var formatRegExp = /%[sdj%]/g;

function format(f) {
    if (typeof f !== 'string') {
        var objects = [];
        for (var argIndex = 0; argIndex < arguments.length; argIndex++) {
            objects.push(inspect(arguments[argIndex]));
        }
        return objects.join(' ');
    }

    if (arguments.length === 1) {
        return f;
    }
    var i = 1;
    var args = arguments;
    var len = args.length;
    var str = String(f).replace(formatRegExp, function(x) {
        if (x === '%%') {
            return '%';
        }
        if (i >= len) {
            return x;
        }
        switch (x) {
            case '%s':
                return String(args[i++]);
            case '%d':
                return Number(args[i++]);
            case '%j':
                try {
                    return JSON.stringify(args[i++]);
                } catch (_) {
                    return '[Circular]';
                } // jshint ignore:line
                // falls through
            default:
                return x;
        }
    });
    for (var x = args[i]; i < len; x = args[++i]) {
        if (x === null || (typeof x !== 'object' && typeof x !== 'symbol')) {
            str += ' ' + x;
        } else {
            str += ' ' + inspect(x);
        }
    }
    return str;
}

function debuglog(set) {
    if (debugEnviron === undefined) {
        debugEnviron = process.env.RUFF_DEBUG || '';
    }
    set = set.toUpperCase();
    if (!debugs[set]) {
        if (new RegExp('\\b' + set + '\\b', 'i').test(debugEnviron)) {
            //TODO process.pid
            // var pid = process.pid;
            debugs[set] = function() {
                var msg = format.apply(exports, arguments);
                console.error('%s %s', set, msg);
            };
        } else {
            debugs[set] = function() {};
        }
    }
    return debugs[set];
}

var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function _pad(n) {
    return n < 10 ? '0' + n.toString(10) : n.toString(10);
}

function _timestamp() {
    var d = new Date();
    var time = [_pad(d.getHours()),
        _pad(d.getMinutes()),
        _pad(d.getSeconds())
    ].join(':');
    return [d.getDate(), months[d.getMonth()], time].join(' ');
}

// log is just a thin wrapper to console.log that prepends a timestamp
function log() {
    console.log('%s - %s', _timestamp(), format.apply(exports, arguments));
}

inspect.colors = {
    'bold': [1, 22],
    'italic': [3, 23],
    'underline': [4, 24],
    'inverse': [7, 27],
    'white': [37, 39],
    'grey': [90, 39],
    'black': [30, 39],
    'blue': [34, 39],
    'cyan': [36, 39],
    'green': [32, 39],
    'magenta': [35, 39],
    'red': [31, 39],
    'yellow': [33, 39]
};

// Don't use 'blue' not visible on cmd.exe
inspect.styles = {
    'special': 'cyan',
    'number': 'yellow',
    'boolean': 'yellow',
    'undefined': 'grey',
    'null': 'bold',
    'string': 'green',
    'symbol': 'green',
    'date': 'magenta',
    // "name": intentionally not styling
    'regexp': 'red'
};


function _stylizeWithColor(str, styleType) {
    var style = inspect.styles[styleType];

    if (style) {
        return '\u001b[' + inspect.colors[style][0] + 'm' + str +
            '\u001b[' + inspect.colors[style][1] + 'm';
    } else {
        return str;
    }
}


function _stylizeNoColor(str) {
    return str;
}


function _formatPrimitive(ctx, value) {
    if (value === undefined) {
        return ctx.stylize('undefined', 'undefined');
    }

    // For some reason typeof null is "object", so special case here.
    if (value === null) {
        return ctx.stylize('null', 'null');
    }

    var type = typeof value;

    if (type === 'string') {
        var simple = '\'' + JSON.stringify(value).replace(/^"|"$/g, '')
            .replace(/'/g, '\\\'')
            .replace(/\\"/g, '"') + '\'';
        return ctx.stylize(simple, 'string');
    }
    if (type === 'number') {
        // Format -0 as '-0'. Strict equality won't distinguish 0 from -0,
        // so instead we use the fact that 1 / -0 < 0 whereas 1 / 0 > 0 .
        if (value === 0 && 1 / value < 0) {
            return ctx.stylize('-0', 'number');
        }
        return ctx.stylize('' + value, 'number');
    }
    if (type === 'boolean') {
        return ctx.stylize('' + value, 'boolean');
    }
    // native object 
    if (type === 'buffer') {
        return 'native object';
    }
    // es6 symbol primitive
    // TODO es6
    // if (type === 'symbol')
    //   return ctx.stylize(value.toString(), 'symbol');
}


function _formatPrimitiveNoColor(ctx, value) {
    var stylize = ctx.stylize;
    ctx.stylize = _stylizeNoColor;
    var str = _formatPrimitive(ctx, value);
    ctx.stylize = stylize;
    return str;
}

function _hasOwnProperty(obj, prop) {
    return Object.prototype.hasOwnProperty.call(obj, prop);
}

function _formatError(value) {
    return '[' + Error.prototype.toString.call(value) + ']';
}

function _formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
    var name, str, desc;
    desc = Object.getOwnPropertyDescriptor(value, key) || {
        value: value[key]
    };
    if (desc.get) {
        if (desc.set) {
            str = ctx.stylize('[Getter/Setter]', 'special');
        } else {
            str = ctx.stylize('[Getter]', 'special');
        }
    } else {
        if (desc.set) {
            str = ctx.stylize('[Setter]', 'special');
        }
    }
    if (!_hasOwnProperty(visibleKeys, key)) {
        name = '[' + key + ']';
    }
    if (!str) {
        if (ctx.seen.indexOf(desc.value) < 0) {
            if (recurseTimes === null) {
                str = _formatValue(ctx, desc.value, null);
            } else {
                str = _formatValue(ctx, desc.value, recurseTimes - 1);
            }
            if (str.indexOf('\n') > -1) {
                if (array) {
                    str = str.split('\n').map(function(line) {
                        return '  ' + line;
                    }).join('\n').substr(2);
                } else {
                    str = '\n' + str.split('\n').map(function(line) {
                        return '   ' + line;
                    }).join('\n');
                }
            }
        } else {
            str = ctx.stylize('[Circular]', 'special');
        }
    }
    if (name === undefined) {
        if (array && key.match(/^\d+$/)) {
            return str;
        }
        name = JSON.stringify('' + key);
        if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
            name = name.substr(1, name.length - 2);
            name = ctx.stylize(name, 'name');
        } else {
            name = name.replace(/'/g, '\\\'')
                .replace(/\\"/g, '"')
                .replace(/(^"|"$)/g, '\'')
                .replace(/\\\\/g, '\\');
            name = ctx.stylize(name, 'string');
        }
    }

    return name + ': ' + str;
}

function _formatObject(ctx, value, recurseTimes, visibleKeys, keys) {
    return keys.map(function(key) {
        return _formatProperty(ctx, value, recurseTimes, visibleKeys, key, false);
    });
}


function _formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
    var output = [];
    for (var i = 0, l = value.length; i < l; ++i) {
        if (_hasOwnProperty(value, String(i))) {
            output.push(_formatProperty(ctx, value, recurseTimes, visibleKeys,
                String(i), true));
        } else {
            output.push('');
        }
    }
    keys.forEach(function(key) {
        if (typeof key === 'symbol' || !key.match(/^\d+$/)) {
            output.push(_formatProperty(ctx, value, recurseTimes, visibleKeys,
                key, true));
        }
    });
    return output;
}

function _objectToString(o) {
    return Object.prototype.toString.call(o);
}

function _isRegExp(re) {
    return _objectToString(re) === '[object RegExp]';
}


function _isDate(d) {
    return _objectToString(d) === '[object Date]';
}


function _isError(e) {
    return _objectToString(e) === '[object Error]' || e instanceof Error;
}

function _extend(origin, add) { // Don't do anything if add isn't an object
    if (add === null || typeof add !== 'object') {
        return origin;
    }

    var keys = Object.keys(add);
    var i = keys.length;
    while (i--) {
        origin[keys[i]] = add[keys[i]];
    }
    return origin;
}

function _arrayToHash(array) {
    var hash = {};

    array.forEach(function(val) {
        hash[val] = true;
    });

    return hash;
}

function _getConstructorOf(obj) {
    while (obj) {
        var descriptor = Object.getOwnPropertyDescriptor(obj, 'constructor');
        if (descriptor !== undefined &&
            typeof descriptor.value === 'function' &&
            descriptor.value.name !== '') {
            return descriptor.value;
        }

        obj = Object.getPrototypeOf(obj);
    }

    return null;
}

function _reduceToSingleString(output, base, braces) {
    var length = output.reduce(function(prev, cur) {
        return prev + cur.replace(/\u001b\[\d\d?m/g, '').length + 1;
    }, 0);

    if (length > 60) {
        return braces[0] +
            // If the opening "brace" is too large, like in the case of "Set {",
            // we need to force the first item to be on the next line or the
            // items will not line up correctly.
            (base === '' && braces[0].length === 1 ? '' : base + '\n ') +
            ' ' +
            output.join(',\n  ') +
            ' ' +
            braces[1];
    }

    return braces[0] + base + ' ' + output.join(', ') + ' ' + braces[1];
}

function _formatValue(ctx, value, recurseTimes) { // jshint ignore:line
    // Provide a hook for user-specified inspect functions.
    // Check that value is an object with an inspect function on it
    if (ctx.customInspect &&
        value &&
        typeof value.inspect === 'function' &&
        // Filter out the util module, it's inspect function is special
        value.inspect !== exports.inspect &&
        // Also filter out any prototype objects using the circular check.
        !(value.constructor && value.constructor.prototype === value)) {
        var ret = value.inspect(recurseTimes, ctx);
        if (typeof ret !== 'string') {
            ret = _formatValue(ctx, ret, recurseTimes);
        }
        return ret;
    }

    // Primitive types cannot have properties
    var primitive = _formatPrimitive(ctx, value);
    if (primitive) {
        return primitive;
    }

    var keys = Object.keys(value);
    var visibleKeys = _arrayToHash(keys);

    if (ctx.showHidden) {
        keys = Object.getOwnPropertyNames(value);
    }

    // This could be a boxed primitive (new String(), etc.), check valueOf()
    // NOTE: Avoid calling `valueOf` on `Date` instance because it will return
    // a number which, when object has some additional user-stored `keys`,
    // will be printed out.
    var formatted;
    var raw = value;
    try {
        // the .valueOf() call can fail for a multitude of reasons
        if (!_isDate(value)) {
            raw = value.valueOf();
        }
    } catch (e) {
        // ignore...
    }

    if (typeof raw === 'string') {
        // for boxed Strings, we have to remove the 0-n indexed entries,
        // since they just noisey up the output and are redundant
        keys = keys.filter(function(key) {
            return !(key >= 0 && key < raw.length);
        });
    }

    // Some type of object without properties can be shortcutted.
    if (keys.length === 0) {
        if (typeof value === 'function') {
            var name = value.name ? ': ' + value.name : '';
            return ctx.stylize('[Function' + name + ']', 'special');
        }
        if (_isRegExp(value)) {
            return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
        }
        if (_isDate(value)) {
            return ctx.stylize(Date.prototype.toString.call(value), 'date');
        }
        if (_isError(value)) {
            return _formatError(value);
        }
        // now check the `raw` value to handle boxed primitives
        if (typeof raw === 'string') {
            formatted = _formatPrimitiveNoColor(ctx, raw);
            return ctx.stylize('[String: ' + formatted + ']', 'string');
        }
        if (typeof raw === 'number') {
            formatted = _formatPrimitiveNoColor(ctx, raw);
            return ctx.stylize('[Number: ' + formatted + ']', 'number');
        }
        if (typeof raw === 'boolean') {
            formatted = _formatPrimitiveNoColor(ctx, raw);
            return ctx.stylize('[Boolean: ' + formatted + ']', 'boolean');
        }
    }

    var constructor = _getConstructorOf(value);
    var base = '',
        empty = false,
        braces, formatter;

    if (Array.isArray(value)) {
        // We can't use `constructor === Array` because this could
        // have come from a Debug context.
        // Otherwise, an Array will print "Array [...]".
        if (constructor && constructor.name === 'Array') {
            constructor = null;
        }
        braces = ['[', ']'];
        empty = value.length === 0;
        formatter = _formatArray;
    } else {
        if (constructor === Object) {
            constructor = null;
        }
        braces = ['{', '}'];
        empty = true; // No other data than keys.
        formatter = _formatObject;
    }

    empty = empty === true && keys.length === 0;

    // Make functions say that they are functions
    if (typeof value === 'function') {
        var n = value.name ? ': ' + value.name : '';
        base = ' [Function' + n + ']';
    }

    // Make RegExps say that they are RegExps
    if (_isRegExp(value)) {
        base = ' ' + RegExp.prototype.toString.call(value);
    }

    // Make dates with properties first say the date
    if (_isDate(value)) {
        base = ' ' + Date.prototype.toUTCString.call(value);
    }

    // Make error with message first say the error
    if (_isError(value)) {
        base = ' ' + _formatError(value);
    }

    // Make boxed primitive Strings look like such
    if (typeof raw === 'string') {
        formatted = _formatPrimitiveNoColor(ctx, raw);
        base = ' ' + '[String: ' + formatted + ']';
    }

    // Make boxed primitive Numbers look like such
    if (typeof raw === 'number') {
        formatted = _formatPrimitiveNoColor(ctx, raw);
        base = ' ' + '[Number: ' + formatted + ']';
    }

    // Make boxed primitive Booleans look like such
    if (typeof raw === 'boolean') {
        formatted = _formatPrimitiveNoColor(ctx, raw);
        base = ' ' + '[Boolean: ' + formatted + ']';
    }

    // Add constructor name if available
    if (base === '' && constructor) {
        braces[0] = constructor.name + ' ' + braces[0];
    }

    if (empty === true) {
        return braces[0] + base + braces[1];
    }

    if (recurseTimes < 0) {
        if (_isRegExp(value)) {
            return ctx.stylize(RegExp.prototype.toString.call(value), 'regexp');
        } else {
            return ctx.stylize('[Object]', 'special');
        }
    }

    ctx.seen.push(value);

    var output = formatter(ctx, value, recurseTimes, visibleKeys, keys);

    ctx.seen.pop();

    return _reduceToSingleString(output, base, braces);
}

function inspect(obj, opts) { // jshint ignore:line
    // default options
    var ctx = {
        seen: [],
        stylize: _stylizeNoColor
    };
    // legacy...
    if (arguments.length >= 3) {
        ctx.depth = arguments[2];
    }
    if (arguments.length >= 4) {
        ctx.colors = arguments[3];
    }
    if (typeof opts === 'boolean') {
        // legacy...
        ctx.showHidden = opts;
    } else if (opts) {
        // got an "options" object
        _extend(ctx, opts);
    }
    // set default options
    if (ctx.showHidden === undefined) {
        ctx.showHidden = false;
    }
    if (ctx.depth === undefined) {
        ctx.depth = 2;
    }
    if (ctx.colors === undefined) {
        ctx.colors = false;
    }
    if (ctx.customInspect === undefined) {
        ctx.customInspect = true;
    }
    if (ctx.colors) {
        ctx.stylize = _stylizeWithColor;
    }
    return _formatValue(ctx, obj, ctx.depth);
}


function inherits(ctor, superCtor) {

    if (ctor === undefined || ctor === null) {
        throw new TypeError('The constructor to `inherits` must not be ' +
            'null or undefined.');
    }

    if (superCtor === undefined || superCtor === null) {
        throw new TypeError('The super constructor to `inherits` must not ' +
            'be null or undefined.');
    }

    if (superCtor.prototype === undefined) {
        throw new TypeError('The super constructor to `inherits` must ' +
            'have a prototype.');
    }

    ctor.super_ = superCtor;
    ctor.prototype = Object.create(superCtor.prototype, {
        constructor: {
            value: ctor,
            enumerable: false,
            writable: true,
            configurable: true
        }
    });
}

function _printDeprecationMessage(msg) {
    //TODO process.noDeprecation has not been achieved
    console.error(msg);
    return true;
}

function deprecate(fn, msg) {
    //TODO process.noDeprecation has not been achieved
    function _deprecated() {
        _printDeprecationMessage(msg);
        return fn.apply(this, arguments); // jshint ignore:line
    }

    return _deprecated;
}

function mixin(base, exts) {
    var proto = base.prototype;
    Array.prototype.forEach.call(exts, function(value) {
        var valueProto = value.prototype;
        for(var props in valueProto) {
            proto[props] = valueProto[props];
        }
    });
}

exports.mixin = mixin;
exports.debuglog = debuglog;
exports.format = format;
exports.log = log;
exports.inspect = inspect;
exports.inherits = inherits;
exports.deprecate = deprecate;
exports.isDate = _isDate;