'use strict';

function isTest(item) {
    return item.indexOf('test') === 0 && item !== 'test';
}

function runMethod(module, item, errors) {
    if (typeof module.beforeEach === 'function') {
        module.beforeEach.call(module);
    }

    try {
        module[item]();
    } catch (e) {
        if (e.stack) {
            console.error(e.stack);
        } else {
            console.error(e);
        }

        errors.push(e);
    }

    if (typeof module.afterEach === 'function') {
        module.afterEach.call(module);
    }

    if (errors.length > 0) {
        console.dir(item + ': error.');
        return;
    }

    console.dir(item + ': passed.', {
        'colors': true
    });
}

function runModule(module, errors) {
    var testsToRun = Object.keys(module).filter(isTest);
    testsToRun.forEach(function(item) {
        var target = module[item];
        var targetType = (typeof target);
        if (targetType === 'function') {
            runMethod(module, item, errors);
        } else if (targetType === 'object') {
            runModule(target, errors);
        }
    });
}

exports.run = function(module) {
    var errors = [];
    runModule(module, errors);
    if (errors.length > 0) {
        throw new Error('test error!');
    }
};