/* globals uv: false */

'use strict';

var TIMEOUT_MAX = 2147483647; // 2^31-1

function _getCallback(callback, args) {
    return function() {
        callback.apply(null, args);
    };
}

function _closeAfterCallback(timer, callback) {
    return function() {
        callback.call();
        timer.close();
    };
}

function _toArrayArgs(argsJson) {
    var len = argsJson.length;
    var args = new Array(len);
    for (var i = 0; i < len; i++) {
        args[i] = argsJson[i];
    }
    return args;
}

var Timer = function() {
    this.timer = uv.new_timer(); // jshint ignore:line
};

Timer.prototype.start = function(callback, after, repeat) {
    if (!this.timer) {
        throw new Error('timer has closed!');
    }
    uv.timer_start(this.timer, after, repeat, callback); // jshint ignore:line
    return this;
};

Timer.prototype.stop = function() {
    if (this.timer) {
        uv.timer_stop(this.timer); // jshint ignore:line
        this.close();
    }
};

Timer.prototype.close = function() {
    if (this.timer) {
        uv.close(this.timer);
        this.timer = null;
    }
};

function _stopTimer(timer) {
    if (timer && timer instanceof Timer) {
        timer.stop();
    }
}

function setTimeout(callback, after) {
    after *= 1; // coalesce to number or NaN

    if (!after || after < 0 || after > TIMEOUT_MAX) {
        after = 0;
    }

    after++; // 0 is conflict with process.nextTick

    var ontimeout = _getCallback(callback, _toArrayArgs(arguments).slice(2));
    var timer = new Timer();
    return timer.start(_closeAfterCallback(timer, ontimeout), after, 0);
}

function _nextTick(callback) {
    var ontimeout = _getCallback(callback, _toArrayArgs(arguments).slice(1));
    var timer = new Timer();
    return timer.start(_closeAfterCallback(timer, ontimeout), 0, 0);
}

function clearTimeout(timer) {
    _stopTimer(timer);
}

function setInterval(callback, repeat) {
    repeat *= 1; // coalesce to number or NaN

    if (!(repeat >= 1 && repeat <= TIMEOUT_MAX)) {
        repeat = 1; // schedule on next tick, follows browser behaviour
    }

    var ontimeout = _getCallback(callback, _toArrayArgs(arguments).slice(2));
    return new Timer().start(ontimeout, 0, repeat);
}

function clearInterval(timer) {
    _stopTimer(timer);
}

function setImmediate(callback) {
    var ontimeout = _getCallback(callback, _toArrayArgs(arguments).slice(1));
    var timer = new Timer();
    return timer.start(_closeAfterCallback(timer, ontimeout), 1, 0);
}

function clearImmediate(timer) {
    _stopTimer(timer);
}

exports.setTimeout = setTimeout;
exports.clearTimeout = clearTimeout;
exports.setInterval = setInterval;
exports.clearInterval = clearInterval;
exports.setImmediate = setImmediate;
exports.clearImmediate = clearImmediate;
exports._nextTick = _nextTick;