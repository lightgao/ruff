'use strict';
/* jshint ignore:start */
var netEvents = require('./net-events.js');
var netUtil   = require('./net-util.js');

function socketCleanupWrap(proto) {

    function _fireErrorCallbacks(self, exception, cb) {
        if (cb) {
            cb(exception);
        }
        if (exception && !self.errorEmitted) {
            process.nextTick(netUtil.emitErrorEvent, self, exception);
            self.errorEmitted = true;
        }
    }

    function cleanupUVHandle(socket, isException) {
        if (socket._uvHandle) {
            uv.close(socket._uvHandle, function () {
                socket.emit('close', !!isException);
            });
            socket._uvHandle = null;
        }
    }

    function cleanupServer(server) {
        if (server) {
            server._connections--;
            if (server._emitCloseIfDrained) {
                server._emitCloseIfDrained();
            }
        }
    }

    proto._destroy = function (exception, cb) {
        if (this.destroyed) {
            return;
        }
        this._connecting = false;
        this.readable    = this.writable = false;
        cleanupUVHandle(this, !!exception);

        // make re-entrance safe in case Socket.prototype.destroy()
        this.destroyed = true;
        _fireErrorCallbacks(this, exception, cb);
        cleanupServer(this.server);
    };

    proto.destroy = function (exception) {
        this._destroy(exception);
    };

    proto._maybeDestroy = function () {
        if (!this.readable && !this.writable && !this.destroyed && !this._connecting) {
            this.destroy();
        }
    };

    proto.end = function (chunk, encoding, cb) {
        this._endWriteStream(chunk, cb, encoding);
        if (this.readable && !this.endEmitted) {
            this.read(); // just in case we're waiting for an EOF.
        } else {
            this._maybeDestroy();
        }
    };

    proto.close = function () {
        if (this._uvHandle) {
            uv.close(this._uvHandle, function () {
            });
        }
    };

    proto.destroySoon = function () {
        if (this.writable) {
            this.end();
        }

        if (this.finished) {
            this.destroy();
        } else {
            this.once(netEvents.SOCKETFINISH, this.destroy);
        }
    };

    // the EOF has been received, and no more bytes are coming.
    // if the writable side has ended already, then clean everything up.
    proto._onSocketEnd = function () {
        // XXX Should not have to do as much crap in this function.
        // ended should already be true, since this is called *after*
        // the EOF errno and onread has eof'ed
        this.ended = true;
        if (this.endEmitted) {
            this.readable = false;
            this._maybeDestroy();
        } else {
            this.once(netEvents.END, function () {
                this.readable = false;
                this._maybeDestroy()
            });
            this.read();
        }

        if (!this.allowHalfOpen) {
            this.destroySoon();
        }
    };
}

exports.socketCleanupWrap = socketCleanupWrap;