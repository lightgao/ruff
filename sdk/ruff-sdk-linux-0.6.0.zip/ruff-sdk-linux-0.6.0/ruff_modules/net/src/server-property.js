'use strict';
/* jshint ignore:start */

function serverPropertyWrap(proto) {
    Object.defineProperty(proto, 'maxConnections', {
        get: function () {
            return this._maxConnections;
        },
        set:function(val){
            this._maxConnections = val;
        }
    });

    proto.address = function(){
        if (this._uvHandle !== null) {
            return uv.tcp_getsockname(this._uvHandle);
        } else {
            return {};
        }
    }
}

exports.serverPropertyWrap = serverPropertyWrap;