'use strict';
/* jshint ignore:start */
var netEvents = require('./net-events.js');

function emitEvent(self, event) {
    if (self._uvHandle) {
        self.emit(event);
    }
}

function onceListener(self, event, eventListener) {
    if (typeof eventListener === 'function') {
        self.once(event, eventListener);
    }
}

function onListener(self, event, eventListener) {
    if (typeof eventListener === 'function') {
        self.on(event, eventListener);
    }
}

function emitErrorEvent(self, err) {
    if(self.emit) {
        self.emit(netEvents.ERROR, err);
    }
}

function getErrorDetail(address, port, additional) {
    var details = (port && port > 0) ? (address + ':' + port) : address;
    details += additional ? ' - Local (' + additional + ')' : '';
    return details;
}

function exceptionWithHostPort(err, syscall, address, port, additional) {
    var ex     = errnoException(err, syscall, getErrorDetail(address, port, additional));
    ex.address = address;
    if (port) {
        ex.port = port;
    }
    return ex;
}

function errnoException(err, syscall, original) {
    var error     = new Error(syscall + ' ' + err);
    error.syscall = syscall;
    error.details = original;
    return error;
}

function cleanupWhenError(self, syscall, error, address, port) {
    var sockName = self._getSockName();
    var details;
    if (sockName) {
        details = sockName.address + ':' + sockName.port;
    }
    var ex = exceptionWithHostPort(error, syscall, address, port, details);
    self._destroy(ex);
}

function wrapCb(self, syscall, cb, address, port) {
    return function (error) {
        if (error) {
            cleanupWhenError(self, syscall, error, address, port);
        } else {
            cb.apply(null, Array.prototype.slice.call(arguments, 1));
        }
    }
}

var ip4Reg = /^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
var ip6Reg = /^([\da-fA-F]{1,4}:){7}[\da-fA-F]{1,4}$/;

function isIP(input) {
    if (ip4Reg.test(input)) {
        return 4;
    }
    if (ip6Reg.test(input)) {
        return 6;
    }
}

function isLegalPort(port) {
    if (typeof port === 'string' && port.trim() === '') {
        return false;
    }
    return +port === (port >>> 0) && port >= 0 && port <= 0xFFFF;
}

exports.emitEvent             = emitEvent;
exports.onceListener          = onceListener;
exports.onListener            = onListener;
exports.emitErrorEvent        = emitErrorEvent;
exports.exceptionWithHostPort = exceptionWithHostPort;
exports.errnoException        = errnoException;
exports.cleanupWhenError      = cleanupWhenError;
exports.wrapCb                = wrapCb;
exports.isIp                  = isIP;
exports.isLegalPort           = isLegalPort;
