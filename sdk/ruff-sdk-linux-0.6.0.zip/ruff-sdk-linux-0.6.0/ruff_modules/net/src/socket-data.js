'use strict';
/* jshint ignore:start */
var netEvents = require('./net-events.js');
var netUtil   = require('./net-util.js');
var Buffer = require('buffer').Buffer;

function readWriteWrap(proto) {

    proto.readStart = function () {
        var socket = this;
        uv.read_start(socket._uvHandle, netUtil.wrapCb(socket, 'read', function (data) {
            if (data) {
                // receive data is duktape buffer type, need convert to Nodejs's Buffer obj.
                socket.emit(netEvents.DATA, new Buffer(data));
            } else if (typeof data === 'undefined') {
                socket.endReading();
            }
        }));
    };

    proto.read = function () {
        if (this._connecting || !this._uvHandle) {
            this.once('connect', this.read.bind(this));
        } else {
            this.readStart();
        }
    };

    proto.write = function (data, encoding, cb) {
        // If we are still connecting, then buffer this for later.
        // The Writable logic will buffer up any more writes while waiting for this one to be done.
        if (this._connecting) {
            this.once('connect', function () {
                this.write(data, encoding, cb);
            });
            return;
        }

        if (!this._uvHandle) {
            this._destroy(new Error('This socket is closed.'), cb);
            return false;
        }

        // so far, we doesn't need encoding info.
        writeToUv(this, data);

        // continue executing without blocking.
        var lastArg = arguments[arguments.length - 1];
        if (typeof lastArg === 'function') {
            lastArg();
        }
    };

    function writeToUv(socket, data) {
        // currently, we only support string and Buffer.
        if (typeof data !== 'string' && !(data instanceof Buffer)) {
            throw new TypeError('invalid data');
        }
        return uv.write(socket._uvHandle, Duktape.Buffer(data), function (err, data) {
            if (err) {
                return socket._destroy(netUtil.errnoException(err, 'write', ''));
            } else {
                socket.emit(netEvents.DRAIN);
            }
        });
    }
}

exports.readWriteWrap = readWriteWrap;
