'use strict';
/* jshint ignore:start */
var netEvents = require('./net-events.js');

function readWriteEndingWrap(proto) {

    function endReadable(socket) {
        var state = socket.state;
        if (!state.endEmitted) {
            state.ended = true;
            process.nextTick(endReadableNT, state, socket);
        }
    }

    function endReadableNT(state, socket) {
        if (!state.endEmitted) {
            state.endEmitted = true;
            socket.readable  = false;
            socket.emit(netEvents.END);
        }
    }

    proto.endReading = function () {
        endReadable(this);
        this._maybeDestroy();

        // internal end event so that we know that the actual socket is no longer readable,
        // and we can start the shutdown procedure. No need to wait for all the data to be consumed.
        this.emit(netEvents.SOCKETEND);
    };

    function finishMaybe(stream, state) {
        if (state.ending && !state.finished) {
            uv.shutdown(stream._uvHandle);
            state.finished = true;
            stream.emit(netEvents.SOCKETFINISH);
        }
    }

    function fireCallbackWhenFinish(stream, state, cb) {
        if (cb) {
            if (state.finished) {
                process.nextTick(cb);
            } else {
                stream.once(netEvents.SOCKETFINISH, cb);
            }
        }
    }

    function endWritable(stream, state, cb) {
        state.ending = true;
        finishMaybe(stream, state);
        fireCallbackWhenFinish(stream, state, cb);
        state.ended  = true;
    }

    proto._endWriteStream = function (chunk, cb, encoding) {
        if (typeof chunk === 'function') {
            cb       = chunk;
            chunk    = null;
            encoding = null;
        } else if (typeof encoding === 'function') {
            cb       = encoding;
            encoding = null;
        }

        if (chunk !== null && chunk !== undefined) {
            this.write(chunk, encoding);
        }

        var state = this.state;
        if (!state.ending && !state.finished) {
            endWritable(this, state, cb);
        }

        this.writable = false;
    };
}

exports.readWriteEndingWrap = readWriteEndingWrap;