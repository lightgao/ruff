'use strict';

module.exports = function () {
    // where magic happens.
    return 'Hello, Ruff';
};
